# Arranca el puente Node (server.mjs) de impresión Brother QL-800 en esta laptop.
# ALTERNATIVA que requiere Node 20+. El camino normal sin Node es agent.ps1
# (Instalar-Impresora-QL.cmd o start.cmd).
# Uso: doble clic en start-node.cmd, o:
#   pwsh -File tools/print-bridge/start.ps1
#   pwsh -File tools/print-bridge/start.ps1 -OpenBrowser

[CmdletBinding()]
param(
  [switch]$OpenBrowser,
  [switch]$SkipInstall
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot

function Write-Step([string]$Msg) {
  Write-Host "[print-bridge] $Msg" -ForegroundColor Cyan
}

function Write-Fail([string]$Msg) {
  Write-Host "[print-bridge] ERROR: $Msg" -ForegroundColor Red
}

Write-Step "carpeta: $Root"

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
  Write-Fail 'Node.js no está en PATH. Instala Node 20+ desde https://nodejs.org y vuelve a correr start.cmd.'
  exit 1
}

$nodeVer = (& node -v) 2>$null
Write-Step "Node $nodeVer"

$envExample = Join-Path $Root '.env.example'
$envFile = Join-Path $Root '.env'
if (-not (Test-Path $envFile)) {
  if (-not (Test-Path $envExample)) {
    Write-Fail 'Falta .env.example'
    exit 1
  }
  Copy-Item -Path $envExample -Destination $envFile
  Write-Step 'creado .env desde .env.example (PRINTER_NAME vacío = auto-detect)'
} else {
  Write-Step '.env ya existe'
}

$pkg = Join-Path $Root 'package.json'
if (-not $SkipInstall -and (Test-Path $pkg)) {
  # package.json sin dependencies hoy; npm/pnpm install es no-op seguro si alguien añade deps.
  $nodeModules = Join-Path $Root 'node_modules'
  if (-not (Test-Path $nodeModules)) {
    Write-Step 'instalando deps (si las hay)…'
    Push-Location $Root
    try {
      if (Get-Command pnpm -ErrorAction SilentlyContinue) {
        & pnpm install --ignore-workspace 2>$null
        if ($LASTEXITCODE -ne 0) { & npm install --omit=dev }
      } else {
        & npm install --omit=dev
      }
    } finally {
      Pop-Location
    }
  }
}

$port = 9631
if (Test-Path $envFile) {
  $portLine = Get-Content $envFile | Where-Object { $_ -match '^\s*PORT\s*=' } | Select-Object -First 1
  if ($portLine -match '=\s*(\d+)') { $port = [int]$Matches[1] }
}

Write-Step "URL http://127.0.0.1:$port"
Write-Step 'Ctrl+C para detener. En Accesos: Imprimir en QL (agente local).'
Write-Step 'Opcional una vez: pwsh -File .\set-ql-media.ps1 (papel default 62mm continua)'

if ($OpenBrowser) {
  Start-Process "http://127.0.0.1:$port/health"
}

Set-Location $Root
& node server.mjs
exit $LASTEXITCODE
