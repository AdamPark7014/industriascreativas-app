﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Instala el agente de impresion ExperienceBT (Brother QL-800) para el usuario actual. Sin admin, sin Node.
.DESCRIPTION
  Doble clic en Instalar-Impresora-QL.cmd (o: powershell -ExecutionPolicy Bypass -File install.ps1).

  1. Desbloquea los archivos (marca de "descargado de Internet").
  2. Copia la carpeta a %LOCALAPPDATA%\ExperienceBT\print-bridge\app\
  3. Crea el acceso directo "ExperienceBT Impresora QL" en Inicio (shell:startup): arranca oculto con Windows.
  4. Comprueba que exista una impresora QL-800; si no, abre la pagina del driver Brother y termina.
  5. Fija el papel por defecto de la QL-800 a 62 mm cinta continua SIN tocar el tipo de rollo (PageOutputColor).
  6. Detiene cualquier agente previo en el puerto (Node o PowerShell).
  7. Arranca el agente oculto, espera /health, abre /health en el navegador e imprime una etiqueta de prueba.
#>
[CmdletBinding()]
param(
  # Puerto del agente. 0 = PORT de .env o 9631.
  [int]$Port = 0,

  # No imprimir la etiqueta de prueba al final.
  [switch]$NoTest,

  # No abrir /health en el navegador.
  [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'

$Source = $PSScriptRoot
$StateDir = Join-Path $env:LOCALAPPDATA 'ExperienceBT\print-bridge'
$AppDir = Join-Path $StateDir 'app'
$LogPath = Join-Path $StateDir 'agent.log'
$PidPath = Join-Path $StateDir 'agent.pid'
$StartupDir = [Environment]::GetFolderPath('Startup')
$ShortcutPath = Join-Path $StartupDir 'ExperienceBT Impresora QL.lnk'
$DriverUrl = 'https://support.brother.com/g/b/downloadtop.aspx?c=us&lang=en&prod=lpql800eus'
$WScriptExe = Join-Path $env:SystemRoot 'System32\wscript.exe'
$RequiredFiles = @('agent.ps1', 'print-label.ps1', 'run-hidden.vbs')
$SkipCopyPatterns = @('*.zip', '*.log', '*.pid', 'pnpm-lock.yaml')

# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------

function Write-Step { param([string]$Msg) Write-Host "[instalar] $Msg" -ForegroundColor Cyan }
function Write-Ok { param([string]$Msg) Write-Host "[instalar] $Msg" -ForegroundColor Green }
function Write-Warn2 { param([string]$Msg) Write-Host "[instalar] AVISO: $Msg" -ForegroundColor Yellow }
function Write-Fail { param([string]$Msg) Write-Host "[instalar] ERROR: $Msg" -ForegroundColor Red }

function Read-DotEnvValue {
  param([string]$Path, [string]$Key)
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  foreach ($line in @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
    $t = ('' + $line).Trim()
    if (-not $t -or $t.StartsWith('#')) { continue }
    $eq = $t.IndexOf('=')
    if ($eq -le 0) { continue }
    if ($t.Substring(0, $eq).Trim() -ne $Key) { continue }
    $v = $t.Substring($eq + 1).Trim()
    if ($v.Length -ge 2 -and (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'")))) {
      $v = $v.Substring(1, $v.Length - 2)
    }
    return $v
  }
  return $null
}

function Invoke-AgentHttp {
  # GET/POST JSON al agente sin proxy y con timeout corto. Devuelve @{ Status; Text; Json }.
  param([string]$Url, [string]$Method = 'GET', [string]$Body = '', [int]$TimeoutSec = 5)
  $req = [Net.HttpWebRequest]::Create($Url)
  $req.Method = $Method
  $req.Timeout = $TimeoutSec * 1000
  $req.ReadWriteTimeout = $TimeoutSec * 1000
  $req.Proxy = $null
  $req.KeepAlive = $false
  if ($Method -eq 'POST') {
    $bytes = [Text.Encoding]::UTF8.GetBytes($Body)
    $req.ContentType = 'application/json'
    $req.ContentLength = $bytes.Length
    $rs = $req.GetRequestStream()
    $rs.Write($bytes, 0, $bytes.Length)
    $rs.Close()
  }
  $resp = $null
  try {
    $resp = $req.GetResponse()
  }
  catch [Net.WebException] {
    if ($_.Exception.Response) { $resp = $_.Exception.Response } else { throw }
  }
  $sr = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)
  $text = $sr.ReadToEnd()
  $sr.Close()
  $status = [int]$resp.StatusCode
  $resp.Close()
  $json = $null
  try { $json = $text | ConvertFrom-Json -ErrorAction Stop } catch { $json = $null }
  return @{ Status = $status; Text = $text; Json = $json }
}

function Get-AncestorPids {
  # PIDs de este proceso y de toda su cadena de padres (consola, cmd, IDE...): nunca se detienen.
  $set = @{}
  try {
    $all = @{}
    foreach ($p in (Get-CimInstance Win32_Process -ErrorAction Stop)) { $all[[int]$p.ProcessId] = [int]$p.ParentProcessId }
    $cur = [int]$PID
    $hops = 0
    while ($cur -gt 0 -and -not $set.ContainsKey($cur) -and $hops -lt 64) {
      $set[$cur] = $true
      if (-not $all.ContainsKey($cur)) { break }
      $cur = $all[$cur]
      $hops++
    }
  }
  catch { $set[[int]$PID] = $true }
  return $set
}

function Get-AgentProcesses {
  # powershell.exe / pwsh.exe lanzados con "-File ...\agent.ps1" (agente oculto o start.cmd).
  # Se exige el patron -File para no confundirlo con una consola cuyo comando solo mencione el nombre.
  $list = @()
  $ancestors = Get-AncestorPids
  try {
    $procs = Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe' OR Name = 'pwsh.exe'" -ErrorAction Stop
    foreach ($p in $procs) {
      $procId = [int]$p.ProcessId
      if ($ancestors.ContainsKey($procId)) { continue }
      if (('' + $p.CommandLine) -match '(?i)-File\s+"?[^"]*\\agent\.ps1"?(\s|$)') { $list += $procId }
    }
  }
  catch { }
  return @($list)
}

function Stop-PreviousAgents {
  param([int]$ListenPort)
  $stopped = @()

  # 1) Quien escucha en el puerto (Node, pwsh, powershell). PID 4 = http.sys (HttpListener de otro agent.ps1).
  $owners = @()
  try {
    $owners = @(Get-NetTCPConnection -LocalPort $ListenPort -State Listen -ErrorAction Stop | ForEach-Object { [int]$_.OwningProcess } | Sort-Object -Unique)
  }
  catch { $owners = @() }
  $ancestors = Get-AncestorPids
  foreach ($ownerPid in $owners) {
    if ($ownerPid -le 4) { continue }
    if ($ancestors.ContainsKey([int]$ownerPid)) {
      Write-Warn2 "el puerto $ListenPort lo usa un proceso padre de este instalador (PID $ownerPid); no lo detengo"
      continue
    }
    try {
      $p = Get-Process -Id $ownerPid -ErrorAction Stop
      if ($p.ProcessName -in @('node', 'powershell', 'pwsh', 'wscript')) {
        Write-Step "deteniendo $($p.ProcessName) (PID $ownerPid) que escuchaba en el puerto $ListenPort"
        Stop-Process -Id $ownerPid -Force -ErrorAction Stop
        $stopped += $ownerPid
      }
      else {
        Write-Warn2 "el puerto $ListenPort lo usa '$($p.ProcessName)' (PID $ownerPid); no lo detengo. Cierra ese programa o cambia PORT en .env."
      }
    }
    catch {
      Write-Warn2 "no se pudo detener PID ${ownerPid}: $($_.Exception.Message)"
    }
  }

  # 2) Cualquier agent.ps1 previo (instalado o suelto), incluido el que responde detras de http.sys.
  foreach ($agentPid in (Get-AgentProcesses)) {
    if ($stopped -contains $agentPid) { continue }
    try {
      Write-Step "deteniendo agente PowerShell previo (PID $agentPid)"
      Stop-Process -Id $agentPid -Force -ErrorAction Stop
      $stopped += $agentPid
    }
    catch { Write-Warn2 "no se pudo detener PID ${agentPid}: $($_.Exception.Message)" }
  }

  # 3) Esperar a que el puerto quede libre.
  $deadline = (Get-Date).AddSeconds(6)
  while ((Get-Date) -lt $deadline) {
    $busy = @()
    try { $busy = @(Get-NetTCPConnection -LocalPort $ListenPort -State Listen -ErrorAction Stop) } catch { $busy = @() }
    if ($busy.Count -eq 0) { break }
    Start-Sleep -Milliseconds 300
  }
  if ($stopped.Count -eq 0) { Write-Step "no habia ningun agente previo en el puerto $ListenPort" }
  return $stopped
}

function Set-QlMedia62Default {
  <#
    Fija el papel por defecto del driver a 62 mm cinta continua (CustomMediaSize259 / ContinuousLengthTape)
    editando SOLO psk:PageMediaSize y ns0001:PaperType sobre el PrintTicket actual. No toca
    psk:PageOutputColor (tipo de rollo mono / negro-rojo): eso lo gestiona print-label.ps1 en cada impresion.
    Devuelve 'ya', 'ok' o 'error:<motivo>'.
  #>
  param([string]$PrinterName)
  $mediaFeatureRe = '(?s)<psf:Feature name="psk:PageMediaSize">.*?</psf:Feature>'
  $paperTypeRe = '(?s)(<psf:Property name="ns0001:PaperType">\s*<psf:Value[^>]*>)[^<]*(</psf:Value>)'
  $colorRe = '(?s)<psf:Feature name="psk:PageOutputColor">.*?</psf:Feature>'
  $mediaBlock = '<psf:Feature name="psk:PageMediaSize"><psf:Option name="ns0001:CustomMediaSize259">' +
  '<psf:ScoredProperty name="psk:MediaSizeWidth"><psf:Value xsi:type="xsd:integer">62000</psf:Value></psf:ScoredProperty>' +
  '<psf:ScoredProperty name="psk:MediaSizeHeight"><psf:Value xsi:type="xsd:integer">100000</psf:Value></psf:ScoredProperty>' +
  '<psf:ScoredProperty name="ns0001:MediaSizeHeightOffset"><psf:Value xsi:type="xsd:integer">3000</psf:Value></psf:ScoredProperty>' +
  '</psf:Option></psf:Feature>'
  $paperTypeBlock = '<psf:Property name="ns0001:PageMediaSizeData"><psf:Property name="ns0001:PaperType"><psf:Value xsi:type="xsd:string">ContinuousLengthTape</psf:Value></psf:Property></psf:Property>'

  try {
    $cfg = Get-PrintConfiguration -PrinterName $PrinterName -ErrorAction Stop
    $xml = [string]$cfg.PrintTicketXml
    if (-not $xml) { return 'error:PrintTicket vacio' }

    $mediaNow = [regex]::Match($xml, $mediaFeatureRe).Value
    $typeNow = [regex]::Match($xml, $paperTypeRe).Value
    if ($mediaNow -match 'CustomMediaSize259' -and $typeNow -match 'ContinuousLengthTape') { return 'ya' }

    $colorBefore = [regex]::Match($xml, $colorRe).Value

    if ([regex]::IsMatch($xml, $mediaFeatureRe)) {
      $new = [regex]::Replace($xml, $mediaFeatureRe, $mediaBlock, 1)
    }
    else {
      $new = $xml -replace '</psf:PrintTicket>', ($mediaBlock + '</psf:PrintTicket>')
    }
    if ([regex]::IsMatch($new, $paperTypeRe)) {
      $new = [regex]::Replace($new, $paperTypeRe, '${1}ContinuousLengthTape${2}', 1)
    }
    else {
      $new = $new -replace '</psf:PrintTicket>', ($paperTypeBlock + '</psf:PrintTicket>')
    }

    Set-PrintConfiguration -PrinterName $PrinterName -PrintTicketXml $new -ErrorAction Stop

    $after = [string](Get-PrintConfiguration -PrinterName $PrinterName -ErrorAction Stop).PrintTicketXml
    $mediaAfter = [regex]::Match($after, $mediaFeatureRe).Value
    $colorAfter = [regex]::Match($after, $colorRe).Value
    if ($mediaAfter -notmatch 'CustomMediaSize259') { return 'error:el driver no acepto CustomMediaSize259' }
    if ($colorBefore -and $colorAfter -and ($colorBefore -ne $colorAfter)) {
      return 'error:PageOutputColor cambio al escribir el ticket (no deberia)'
    }
    return 'ok'
  }
  catch {
    return ('error:' + $_.Exception.Message)
  }
}

# ---------------------------------------------------------------------------
# 1. Desbloquear archivos de origen
# ---------------------------------------------------------------------------

Write-Host ''
Write-Host '=== ExperienceBT - Instalar impresora Brother QL-800 (agente local) ===' -ForegroundColor White
Write-Step "origen: $Source"
Write-Step "destino: $AppDir"

foreach ($f in $RequiredFiles) {
  if (-not (Test-Path -LiteralPath (Join-Path $Source $f))) {
    Write-Fail "falta $f junto a install.ps1. Descomprime el ZIP completo (Extraer todo) y vuelve a intentarlo."
    exit 1
  }
}

try {
  Get-ChildItem -LiteralPath $Source -File | Unblock-File -ErrorAction SilentlyContinue
  Write-Step 'archivos desbloqueados (marca de Internet quitada)'
}
catch { Write-Warn2 "Unblock-File: $($_.Exception.Message)" }

# ---------------------------------------------------------------------------
# 2. Copiar a %LOCALAPPDATA%\ExperienceBT\print-bridge\app
# ---------------------------------------------------------------------------

New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
New-Item -ItemType Directory -Force -Path $AppDir | Out-Null

$sameFolder = ($Source.TrimEnd('\') -ieq $AppDir.TrimEnd('\'))
if ($sameFolder) {
  Write-Step 'ya se ejecuta desde la carpeta instalada; no hace falta copiar'
}
else {
  $copied = 0
  foreach ($file in (Get-ChildItem -LiteralPath $Source -File)) {
    $skip = $false
    foreach ($pat in $SkipCopyPatterns) { if ($file.Name -like $pat) { $skip = $true; break } }
    if ($skip) { continue }
    Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $AppDir $file.Name) -Force
    $copied++
  }
  Get-ChildItem -LiteralPath $AppDir -File | Unblock-File -ErrorAction SilentlyContinue
  Write-Step "copiados $copied archivos"
}

$envPath = Join-Path $AppDir '.env'
if ($Port -le 0) {
  $envPort = Read-DotEnvValue -Path $envPath -Key 'PORT'
  $parsed = 0
  if ($envPort -and [int]::TryParse($envPort, [ref]$parsed) -and $parsed -gt 0) { $Port = $parsed } else { $Port = 9631 }
}
$BaseUrl = "http://127.0.0.1:$Port"

# ---------------------------------------------------------------------------
# 3. Acceso directo en Inicio (shell:startup)
# ---------------------------------------------------------------------------

try {
  New-Item -ItemType Directory -Force -Path $StartupDir | Out-Null
  $shell = New-Object -ComObject WScript.Shell
  $lnk = $shell.CreateShortcut($ShortcutPath)
  $lnk.TargetPath = $WScriptExe
  $lnk.Arguments = '"' + (Join-Path $AppDir 'run-hidden.vbs') + '"'
  $lnk.WorkingDirectory = $AppDir
  $lnk.WindowStyle = 7
  $lnk.Description = 'Agente local de impresion ExperienceBT (Brother QL-800). Se inicia con Windows.'
  $lnk.IconLocation = (Join-Path $env:SystemRoot 'System32\printui.dll') + ',0'
  $lnk.Save()
  Write-Step "acceso directo en Inicio: $ShortcutPath"
}
catch {
  Write-Warn2 "no se pudo crear el acceso directo de Inicio: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 4. Driver / impresora QL-800
# ---------------------------------------------------------------------------

$ql = @()
try { $ql = @(Get-Printer -ErrorAction Stop | Where-Object { $_.Name -match 'QL-?800' }) } catch { $ql = @() }
if ($ql.Count -eq 0) {
  Write-Host ''
  Write-Fail 'No hay ninguna impresora "QL-800" instalada en Windows.'
  Write-Host ''
  Write-Host '  1. Instala el driver de Brother QL-800 (se abre la pagina oficial de descarga).' -ForegroundColor Yellow
  Write-Host '  2. Conecta la impresora por USB y enciendela; debe aparecer en Configuracion > Impresoras.' -ForegroundColor Yellow
  Write-Host '  3. Vuelve a hacer doble clic en Instalar-Impresora-QL.cmd.' -ForegroundColor Yellow
  Write-Host ''
  Write-Host "  Driver: $DriverUrl"
  try { Start-Process $DriverUrl } catch { }
  Write-Host ''
  Write-Host 'El agente ya quedo instalado y arrancara con Windows; solo falta el driver.' -ForegroundColor Yellow
  exit 2
}
$printerName = $ql[0].Name
Write-Ok "impresora encontrada: $printerName (puerto $($ql[0].PortName), estado $($ql[0].PrinterStatus))"

# ---------------------------------------------------------------------------
# 5. Papel por defecto 62 mm continua (sin tocar tipo de rollo)
# ---------------------------------------------------------------------------

$media = Set-QlMedia62Default -PrinterName $printerName
switch -Wildcard ($media) {
  'ya' { Write-Step 'papel por defecto ya era 62 mm cinta continua' }
  'ok' { Write-Ok 'papel por defecto fijado a 62 mm cinta continua (tipo de rollo intacto)' }
  default { Write-Warn2 "no se pudo fijar el papel por defecto ($media). No pasa nada: el agente fuerza 62 mm en cada impresion." }
}

# ---------------------------------------------------------------------------
# 6. Detener agentes previos
# ---------------------------------------------------------------------------

[void](Stop-PreviousAgents -ListenPort $Port)

# ---------------------------------------------------------------------------
# 7. Arrancar oculto y comprobar /health
# ---------------------------------------------------------------------------

$vbs = Join-Path $AppDir 'run-hidden.vbs'
Write-Step "arrancando agente oculto ($vbs)"
Start-Process -FilePath $WScriptExe -ArgumentList ('"' + $vbs + '"') -WorkingDirectory $AppDir -WindowStyle Hidden | Out-Null

$health = $null
$deadline = (Get-Date).AddSeconds(15)
while ((Get-Date) -lt $deadline) {
  Start-Sleep -Milliseconds 500
  try {
    $r = Invoke-AgentHttp -Url "$BaseUrl/health" -TimeoutSec 3
    if ($r.Status -eq 200 -and $r.Json -and $r.Json.ok) { $health = $r.Json; break }
  }
  catch { }
}

if ($null -eq $health) {
  Write-Fail "el agente no respondio en $BaseUrl/health en 15 s."
  if (Test-Path -LiteralPath $LogPath) {
    Write-Host '--- ultimas lineas de agent.log ---'
    Get-Content -LiteralPath $LogPath -Tail 15 | ForEach-Object { Write-Host "  $_" }
  }
  Write-Host "Prueba a arrancarlo visible con start.cmd para ver el error."
  exit 3
}

$agentKind = '' + $health.agent
if ($agentKind -ne 'powershell') {
  Write-Warn2 "en $BaseUrl responde un agente '$agentKind' (no el PowerShell recien instalado). Cierra el otro y repite."
}
Write-Ok ("agente {0} v{1} activo en {2} (PID {3}) - impresora: {4} [{5}] - rollo recordado: {6}" -f $agentKind, $health.version, $BaseUrl, $health.pid, $health.printerName, $health.printerSource, $(if ($health.colorMode) { $health.colorMode } else { 'aun no detectado' }))

if (-not $NoBrowser) {
  try { Start-Process "$BaseUrl/health" } catch { }
}

if (-not $NoTest) {
  Write-Step 'imprimiendo etiqueta de prueba (detecta solo si el rollo es monocromo o negro/rojo)...'
  try {
    $t = Invoke-AgentHttp -Url "$BaseUrl/test" -Method POST -Body '{}' -TimeoutSec 150
    if ($t.Status -eq 200 -and $t.Json -and $t.Json.ok) {
      Write-Ok ("etiqueta de prueba enviada: papel={0} rollo={1} ({2}) estado={3}" -f $t.Json.paper, $t.Json.colorMode, $t.Json.colorModeSource, $t.Json.watched)
    }
    else {
      $msg = ''
      if ($t.Json -and $t.Json.error) { $msg = $t.Json.error } else { $msg = $t.Text }
      Write-Warn2 "la etiqueta de prueba fallo (HTTP $($t.Status)): $msg"
      Write-Host '  Revisa: rollo 62 mm cinta continua cargado, tapa cerrada, USB conectado, cola de impresion sin trabajos atascados.' -ForegroundColor Yellow
    }
  }
  catch {
    Write-Warn2 "no se pudo pedir la etiqueta de prueba: $($_.Exception.Message)"
  }
}

Write-Host ''
Write-Host 'Listo. En Accesos usa Imprimir en QL.' -ForegroundColor Green
Write-Host ''
Write-Host "  Estado del agente:  $BaseUrl/health"
Write-Host "  Log:                $LogPath"
Write-Host "  Desinstalar:        Desinstalar-Impresora-QL.cmd"
Write-Host ''
exit 0
