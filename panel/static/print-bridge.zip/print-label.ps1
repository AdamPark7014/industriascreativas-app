#Requires -Version 5.1
<#
.SYNOPSIS
  Imprime una etiqueta en Brother QL-800 (u otra impresora Windows) forzando media 62mm continua.
.DESCRIPTION
  Usado por tools/print-bridge. DocumentName fijo ExperienceBT-QL-62x100 (nunca hereda título del browser).
  PaperSize.Width/Height en System.Drawing son hundredths of an inch (62mm ≈ 244).
#>
param(
  [Parameter(Mandatory = $true)]
  [string]$PrinterName,

  [Parameter(Mandatory = $true)]
  [string]$Title,

  [string]$Body = '',

  [string]$Footer = '',

  # Label size in hundredths of mm (bridge convention): 62mm = 6200
  [int]$WidthHmm = 6200,

  [int]$HeightHmm = 10000,

  # Preferred media: UI/driver may say "62mm Cinta continua"; GDI PaperName is often just "62mm"
  [string]$MediaName = '62mm Cinta continua',

  # Spooler / Brother status job title — never inherit SPA/browser document title
  [string]$JobName = 'ExperienceBT-QL-62x100',

  [string]$PngPath = '',

  [string]$PngBase64 = '',

  # Fail instead of printing on wrong / unmatched media
  [switch]$RequireMediaMatch
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

function Convert-HmmToHi {
  param([int]$Hmm)
  # hundredths of mm → hundredths of inch
  return [int][Math]::Round($Hmm * 100.0 / 2540.0)
}

function Find-QlContinuous62 {
  param(
    [System.Drawing.Printing.PrinterSettings]$Settings,
    [string]$WantedName,
    [int]$WidthHi,
    [int]$HeightHi
  )

  $candidates = @($Settings.PaperSizes)
  $exactAliases = @(
    $WantedName,
    '62mm Cinta continua',
    '62mm Continuous Length',
    '62mm Continuous',
    '62 mm Continuous',
    '62mm'
  ) | Where-Object { $_ } | Select-Object -Unique

  foreach ($alias in $exactAliases) {
    foreach ($ps in $candidates) {
      if ($ps.PaperName -eq $alias) {
        return @{ Paper = $ps; How = "exact:$alias" }
      }
    }
  }

  # Continuous roll: name is often just "62mm" (no "x NN"). Prefer that over "62mm x 100mm" die-cut.
  foreach ($ps in $candidates) {
    $n = $ps.PaperName
    if ($n -match 'continua|continuous|cinta') {
      if ($n -match '62') {
        return @{ Paper = $ps; How = "name-continua:$n" }
      }
    }
  }

  foreach ($ps in $candidates) {
    $n = $ps.PaperName
    # Exact continuous form: "62mm" / "62 mm" without "x" (die-cuts are "62mm x 100mm")
    if ($n -match '^\s*62\s*mm\s*$' -and $n -notmatch 'x') {
      return @{ Paper = $ps; How = "name-roll:$n" }
    }
  }

  # Width match in hundredths of inch (±8 ≈ 2mm), prefer non-diecut names
  $best = $null
  $bestDelta = [int]::MaxValue
  $bestHow = ''
  foreach ($ps in $candidates) {
    $n = $ps.PaperName
    if ($n -match '29\s*mm' -and $n -notmatch '62') { continue }
    $dw = [Math]::Abs($ps.Width - $WidthHi)
    if ($dw -gt 12) { continue }
    $isDiecut = $n -match 'x\s*\d'
    $isCont = ($n -match 'continua|continuous|cinta') -or ($n -match '^\s*62\s*mm\s*$')
    $dh = [Math]::Abs($ps.Height - $HeightHi)
    $delta = $dw + $(if ($isCont) { [Math]::Min($dh, 40) } else { $dh })
    if ($isDiecut -and -not $isCont) { $delta += 80 }
    if ($delta -lt $bestDelta) {
      $bestDelta = $delta
      $best = $ps
      $bestHow = "width:$n(d=$delta)"
    }
  }
  if ($best) {
    return @{ Paper = $best; How = $bestHow }
  }

  return $null
}

$doc = New-Object System.Drawing.Printing.PrintDocument
$doc.PrinterSettings.PrinterName = $PrinterName
if (-not $doc.PrinterSettings.IsValid) {
  throw "Impresora no válida o no instalada: $PrinterName"
}

# NEVER inherit browser/SPA title — Brother status shows this string
if (-not $JobName) { $JobName = 'ExperienceBT-QL-62x100' }
$doc.DocumentName = $JobName
$doc.OriginAtMargins = $false
$doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins 0, 0, 0, 0
$doc.DefaultPageSettings.Landscape = $false

$widthHi = Convert-HmmToHi $WidthHmm
$heightHi = Convert-HmmToHi $HeightHmm

$found = Find-QlContinuous62 -Settings $doc.PrinterSettings -WantedName $MediaName -WidthHi $widthHi -HeightHi $heightHi
$matched = $false
$matchHow = 'none'

if ($found) {
  $doc.DefaultPageSettings.PaperSize = $found.Paper
  $doc.PrinterSettings.DefaultPageSettings.PaperSize = $found.Paper
  $matched = $true
  $matchHow = $found.How
}

if (-not $matched) {
  $custom = New-Object System.Drawing.Printing.PaperSize('ExperienceBT-62x100', $widthHi, $heightHi)
  $doc.DefaultPageSettings.PaperSize = $custom
  $doc.PrinterSettings.DefaultPageSettings.PaperSize = $custom
  $matchHow = 'custom-hi'
  if ($RequireMediaMatch) {
    $names = ($doc.PrinterSettings.PaperSizes | ForEach-Object { $_.PaperName }) -join '; '
    throw "Media 62mm continua no encontrada en driver. Pedido='$MediaName'. Disponibles: $names"
  }
}

# Reject obvious 29mm die-cut if we somehow landed there
$paperName = $doc.DefaultPageSettings.PaperSize.PaperName
if ($paperName -match '29\s*mm\s*x\s*90' -or ($paperName -match '29\s*mm' -and $paperName -match '90')) {
  throw "Abortado: paper resuelto a '$paperName' (29×90). Fuerza form 62mm continua en el driver Brother."
}

$script:titleText = $Title
$script:bodyText = $Body
$script:footerText = $Footer
$script:pngImage = $null
$script:pngStream = $null

if ($PngPath -and (Test-Path -LiteralPath $PngPath)) {
  $script:pngImage = [System.Drawing.Image]::FromFile((Resolve-Path -LiteralPath $PngPath))
}
elseif ($PngBase64) {
  $raw = $PngBase64.Trim()
  if ($raw -match '^data:image/[^;]+;base64,(.+)$') {
    $raw = $Matches[1]
  }
  $bytes = [Convert]::FromBase64String($raw)
  $ms = New-Object System.IO.MemoryStream(,$bytes)
  $script:pngImage = [System.Drawing.Image]::FromStream($ms)
  $script:pngStream = $ms
}

$doc.add_PrintPage({
  param($sender, $e)

  if ($null -ne $script:pngImage) {
    $e.Graphics.DrawImage($script:pngImage, $e.PageBounds)
    $e.HasMorePages = $false
    return
  }

  $bounds = $e.MarginBounds
  if ($bounds.Width -le 0 -or $bounds.Height -le 0) {
    $bounds = $e.PageBounds
    $bounds = New-Object System.Drawing.Rectangle(
      ($bounds.X + 8), ($bounds.Y + 8),
      [Math]::Max(8, $bounds.Width - 16),
      [Math]::Max(8, $bounds.Height - 16)
    )
  }

  $y = $bounds.Top
  $brush = [System.Drawing.Brushes]::Black
  $fontTitle = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
  $fontBody = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Regular)
  $fontFoot = New-Object System.Drawing.Font('Consolas', 7, [System.Drawing.FontStyle]::Regular)

  try {
    $e.Graphics.DrawString($script:titleText, $fontTitle, $brush, $bounds.Left, $y)
    $y += [int]($fontTitle.GetHeight($e.Graphics) + 4)

    if ($script:bodyText) {
      foreach ($line in ($script:bodyText -split "`n")) {
        $e.Graphics.DrawString($line, $fontBody, $brush, $bounds.Left, $y)
        $y += [int]($fontBody.GetHeight($e.Graphics) + 1)
        if ($y -gt ($bounds.Bottom - 18)) { break }
      }
    }

    if ($script:footerText) {
      $fh = $fontFoot.GetHeight($e.Graphics)
      $e.Graphics.DrawString(
        $script:footerText,
        $fontFoot,
        $brush,
        $bounds.Left,
        [Math]::Max($y + 2, $bounds.Bottom - $fh - 2)
      )
    }
  }
  finally {
    $fontTitle.Dispose()
    $fontBody.Dispose()
    $fontFoot.Dispose()
  }

  $e.HasMorePages = $false
})

$paperUsed = $doc.DefaultPageSettings.PaperSize.PaperName
$paperW = $doc.DefaultPageSettings.PaperSize.Width
$paperH = $doc.DefaultPageSettings.PaperSize.Height

try {
  Write-Host "[print-label] job=$JobName paper='$paperUsed' W=$paperW H=$paperH how=$matchHow"
  $doc.Print()
}
finally {
  $doc.Dispose()
  if ($null -ne $script:pngImage) { $script:pngImage.Dispose() }
  if ($null -ne $script:pngStream) { $script:pngStream.Dispose() }
}

Write-Output (@{
  ok = $true
  printer = $PrinterName
  paper = $paperUsed
  paperWidthHi = $paperW
  paperHeightHi = $paperH
  matchHow = $matchHow
  documentName = $JobName
  mode = $(if ($PngPath -or $PngBase64) { 'png' } else { 'text' })
} | ConvertTo-Json -Compress)
