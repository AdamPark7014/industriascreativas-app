#Requires -Version 5.1
<#
.SYNOPSIS
  Imprime una etiqueta en Brother QL-800 forzando media 62mm continua y detectando el tipo de rollo.
.DESCRIPTION
  Usado por tools/print-bridge (server.mjs y agent.ps1). DocumentName fijo ExperienceBT-QL-62x100.

  Dos cosas que la Brother exige y que Chrome no puede fijar:
  1. Papel: form GDI "62mm" (cinta continua, RawKind 259). Nunca 29x90.
  2. Tipo de papel (PageOutputColor): un rollo DK-2251 negro/rojo exige Color=true;
     un rollo monocromo (DK-22205, etc.) exige Color=false. Si no coincide, la Brother
     PAUSA el job con error "cambie el tipo de papel a Negro/Rojo" y nada sale.

  Este script vigila la cola tras spoolear: si el job entra en Error/Paused lo cancela,
  reintenta con el otro modo de color, guarda el modo que funcionó en
  %LOCALAPPDATA%\ExperienceBT\print-bridge\state.json y lo replica al default de Windows
  (Set-PrintConfiguration -Color) para que Chrome/P-touch tambien coincidan.

  Salida: ultima linea JSON (ok, paper, colorMode, attempts...). Exit 1 con mensaje en stderr si falla.
#>
param(
  [Parameter(Mandatory = $true)]
  [string]$PrinterName,

  [Parameter(Mandatory = $true)]
  [string]$Title,

  [string]$Body = '',

  [string]$Footer = '',

  # Label size in hundredths of mm (bridge convention): 62mm = 6200
  [int]$WidthHmm = 6200,

  [int]$HeightHmm = 10000,

  # Preferred media: UI/driver may say "62mm Cinta continua"; GDI PaperName is often just "62mm"
  [string]$MediaName = '62mm Cinta continua',

  # Spooler / Brother status job title — never inherit SPA/browser document title
  [string]$JobName = 'ExperienceBT-QL-62x100',

  [string]$PngPath = '',

  [string]$PngBase64 = '',

  # auto = ultimo modo que funciono -> default Windows -> el otro. mono / redblack = forzar.
  [ValidateSet('auto', 'mono', 'redblack')]
  [string]$ColorMode = 'auto',

  # Segundos maximos vigilando la cola por intento
  [int]$WatchSeconds = 12,

  # No reintentar con el otro modo de color
  [switch]$NoRetry,

  # Fail instead of printing on wrong / unmatched media
  [switch]$RequireMediaMatch
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

function Convert-HmmToHi {
  param([int]$Hmm)
  # hundredths of mm -> hundredths of inch
  return [int][Math]::Round($Hmm * 100.0 / 2540.0)
}

function Write-Log {
  param([string]$Msg)
  Write-Host "[print-label] $Msg"
}

function Find-QlContinuous62 {
  param(
    [System.Drawing.Printing.PrinterSettings]$Settings,
    [string]$WantedName,
    [int]$WidthHi,
    [int]$HeightHi
  )

  $candidates = @($Settings.PaperSizes)
  $exactAliases = @(
    $WantedName,
    '62mm Cinta continua',
    '62mm Continuous Length',
    '62mm Continuous',
    '62 mm Continuous',
    '62mm'
  ) | Where-Object { $_ } | Select-Object -Unique

  foreach ($alias in $exactAliases) {
    foreach ($ps in $candidates) {
      if ($ps.PaperName -eq $alias) {
        return @{ Paper = $ps; How = "exact:$alias" }
      }
    }
  }

  # Continuous roll: name is often just "62mm" (no "x NN"). Prefer that over "62mm x 100mm" die-cut.
  foreach ($ps in $candidates) {
    $n = $ps.PaperName
    if ($n -match 'continua|continuous|cinta') {
      if ($n -match '62') {
        return @{ Paper = $ps; How = "name-continua:$n" }
      }
    }
  }

  foreach ($ps in $candidates) {
    $n = $ps.PaperName
    if ($n -match '^\s*62\s*mm\s*$' -and $n -notmatch 'x') {
      return @{ Paper = $ps; How = "name-roll:$n" }
    }
  }

  # Width match in hundredths of inch (+-8 ~ 2mm), prefer non-diecut names
  $best = $null
  $bestDelta = [int]::MaxValue
  $bestHow = ''
  foreach ($ps in $candidates) {
    $n = $ps.PaperName
    if ($n -match '29\s*mm' -and $n -notmatch '62') { continue }
    $dw = [Math]::Abs($ps.Width - $WidthHi)
    if ($dw -gt 12) { continue }
    $isDiecut = $n -match 'x\s*\d'
    $isCont = ($n -match 'continua|continuous|cinta') -or ($n -match '^\s*62\s*mm\s*$')
    $dh = [Math]::Abs($ps.Height - $HeightHi)
    $delta = $dw + $(if ($isCont) { [Math]::Min($dh, 40) } else { $dh })
    if ($isDiecut -and -not $isCont) { $delta += 80 }
    if ($delta -lt $bestDelta) {
      $bestDelta = $delta
      $best = $ps
      $bestHow = "width:$n(d=$delta)"
    }
  }
  if ($best) {
    return @{ Paper = $best; How = $bestHow }
  }

  return $null
}

# --- estado persistente (modo de color que funciono por impresora) ---------

function Get-StatePath {
  $dir = Join-Path $env:LOCALAPPDATA 'ExperienceBT\print-bridge'
  if (-not (Test-Path -LiteralPath $dir)) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
  }
  return (Join-Path $dir 'state.json')
}

function Read-BridgeState {
  $path = Get-StatePath
  if (-not (Test-Path -LiteralPath $path)) { return @{ printers = @{} } }
  try {
    $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
    $obj = $raw | ConvertFrom-Json -ErrorAction Stop
    $state = @{ printers = @{} }
    if ($obj.printers) {
      foreach ($p in $obj.printers.PSObject.Properties) {
        $state.printers[$p.Name] = @{
          colorMode = [string]$p.Value.colorMode
          paper     = [string]$p.Value.paper
          updatedAt = [string]$p.Value.updatedAt
        }
      }
    }
    return $state
  }
  catch {
    return @{ printers = @{} }
  }
}

function Save-BridgeState {
  param([hashtable]$State)
  try {
    $out = @{ printers = @{} }
    foreach ($k in $State.printers.Keys) { $out.printers[$k] = $State.printers[$k] }
    ($out | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath (Get-StatePath) -Encoding UTF8
  }
  catch {
    Write-Log "no se pudo guardar state.json: $($_.Exception.Message)"
  }
}

# --- default de Windows (lo que usan Chrome / P-touch) ----------------------

$script:OutputColorFeatureRe = '(?s)(<psf:Feature name="psk:PageOutputColor">).*?(</psf:Feature>)'

function Get-WindowsColorMode {
  # Lee el PrintTicket del driver: psk:Color = negro/rojo, psk:Monochrome = mono.
  param([string]$Printer)
  try {
    $cfg = Get-PrintConfiguration -PrinterName $Printer -ErrorAction Stop
    $m = [regex]::Match([string]$cfg.PrintTicketXml, $script:OutputColorFeatureRe)
    if (-not $m.Success) { return $null }
    if ($m.Value -match 'Option name="psk:Color"') { return 'redblack' }
    if ($m.Value -match 'Option name="psk:Monochrome"') { return 'mono' }
    return $null
  }
  catch {
    return $null
  }
}

function Set-WindowsColorMode {
  # Escribe psk:PageOutputColor en el PrintTicket del driver (lo unico que Brother respeta).
  param([string]$Printer, [string]$Mode)
  try {
    $option = $(if ($Mode -eq 'redblack') { 'psk:Color' } else { 'psk:Monochrome' })
    $cfg = Get-PrintConfiguration -PrinterName $Printer -ErrorAction Stop
    $xml = [string]$cfg.PrintTicketXml
    $feature = "<psf:Feature name=`"psk:PageOutputColor`"><psf:Option name=`"$option`"/></psf:Feature>"
    if ([regex]::IsMatch($xml, $script:OutputColorFeatureRe)) {
      $new = [regex]::Replace($xml, $script:OutputColorFeatureRe, "`$1<psf:Option name=`"$option`"/>`$2")
    }
    else {
      $new = $xml -replace '</psf:PrintTicket>', "$feature</psf:PrintTicket>"
    }
    Set-PrintConfiguration -PrinterName $Printer -PrintTicketXml $new -ErrorAction Stop
    $check = Get-WindowsColorMode -Printer $Printer
    if ($check -ne $Mode) {
      Write-Log "ticket escrito pero el driver reporta '$check' (pedido $Mode)"
      return $false
    }
    Write-Log "driver Windows: Tipo de papel = $Mode ($option)"
    return $true
  }
  catch {
    Write-Log "no se pudo fijar Tipo de papel ($Mode): $($_.Exception.Message)"
    return $false
  }
}

function Resolve-ModeOrder {
  param([string]$Requested, [string]$Remembered, [string]$WindowsDefault, [bool]$AllowRetry)
  $order = New-Object System.Collections.Generic.List[string]
  $sources = @{}
  if ($Requested -ne 'auto') {
    $order.Add($Requested); $sources[$Requested] = 'forced'
  }
  else {
    if ($Remembered -and -not $order.Contains($Remembered)) { $order.Add($Remembered); $sources[$Remembered] = 'state' }
    if ($WindowsDefault -and -not $order.Contains($WindowsDefault)) { $order.Add($WindowsDefault); $sources[$WindowsDefault] = 'windows' }
    if ($order.Count -eq 0) { $order.Add('mono'); $sources['mono'] = 'default' }
  }
  if ($AllowRetry) {
    foreach ($m in @('mono', 'redblack')) {
      if (-not $order.Contains($m)) { $order.Add($m); $sources[$m] = 'retry' }
    }
  }
  return @{ Order = @($order); Sources = $sources }
}

# --- cola de impresion ------------------------------------------------------

function Get-QueueIds {
  param([string]$Printer)
  try {
    return @(Get-PrintJob -PrinterName $Printer -ErrorAction Stop | ForEach-Object { [int]$_.Id })
  }
  catch { return @() }
}

function Watch-SpoolJob {
  <#
    Devuelve @{ Result = 'printed'|'error'|'timeout'; Status; JobId }.
    'error' = la Brother rechazo el job (Error, o Paused sostenido: tipo de papel / rollo / tapa).
  #>
  param([string]$Printer, [int[]]$ExistingIds, [string]$JobPrefix, [int]$Seconds)

  $deadline = (Get-Date).AddSeconds([Math]::Max(3, $Seconds))
  $job = $null
  $sawJob = $false
  $lastStatus = ''
  $pausedSince = $null

  while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 350
    $jobs = @()
    try { $jobs = @(Get-PrintJob -PrinterName $Printer -ErrorAction Stop) } catch { $jobs = @() }
    $mine = @($jobs | Where-Object { ($ExistingIds -notcontains [int]$_.Id) -and ($_.DocumentName -like "$JobPrefix*") })

    if ($mine.Count -gt 0) {
      $job = $mine[0]
      $sawJob = $true
      $lastStatus = [string]$job.JobStatus
      if ($lastStatus -match 'Error|Offline|PaperOut|UserIntervention|Blocked') {
        return @{ Result = 'error'; Status = $lastStatus; JobId = [int]$job.Id }
      }
      if ($lastStatus -match 'Paused') {
        if ($null -eq $pausedSince) { $pausedSince = Get-Date }
        elseif (((Get-Date) - $pausedSince).TotalSeconds -ge 3) {
          return @{ Result = 'error'; Status = $lastStatus; JobId = [int]$job.Id }
        }
      }
      else {
        $pausedSince = $null
      }
      if ($lastStatus -match 'Printed|Deleting|Deleted' -and $lastStatus -notmatch 'Printing') {
        return @{ Result = 'printed'; Status = $lastStatus; JobId = [int]$job.Id }
      }
    }
    elseif ($sawJob) {
      # Estuvo en cola y desaparecio sin error: impreso.
      return @{ Result = 'printed'; Status = 'done'; JobId = [int]$job.Id }
    }
  }

  if (-not $sawJob) {
    # Job tan pequeno que salio antes del primer sondeo.
    return @{ Result = 'printed'; Status = 'fast'; JobId = $null }
  }
  return @{ Result = 'timeout'; Status = $lastStatus; JobId = [int]$job.Id }
}

function Remove-SpoolJob {
  param([string]$Printer, [int]$JobId)
  $deadline = (Get-Date).AddSeconds(8)
  while ((Get-Date) -lt $deadline) {
    try { Remove-PrintJob -PrinterName $Printer -ID $JobId -ErrorAction Stop } catch { }
    Start-Sleep -Milliseconds 300
    $still = $null
    try { $still = Get-PrintJob -PrinterName $Printer -ErrorAction Stop | Where-Object { [int]$_.Id -eq $JobId } } catch { }
    if (-not $still) { return $true }
  }
  return $false
}

# ---------------------------------------------------------------------------
# Impresora, papel, imagen
# ---------------------------------------------------------------------------

$probe = New-Object System.Drawing.Printing.PrinterSettings
$probe.PrinterName = $PrinterName
if (-not $probe.IsValid) {
  throw "Impresora no valida o no instalada: $PrinterName"
}

if (-not $JobName) { $JobName = 'ExperienceBT-QL-62x100' }

$widthHi = Convert-HmmToHi $WidthHmm
$heightHi = Convert-HmmToHi $HeightHmm

$found = Find-QlContinuous62 -Settings $probe -WantedName $MediaName -WidthHi $widthHi -HeightHi $heightHi
$paperSize = $null
$matchHow = 'none'
if ($found) {
  $paperSize = $found.Paper
  $matchHow = $found.How
}
else {
  $paperSize = New-Object System.Drawing.Printing.PaperSize('ExperienceBT-62x100', $widthHi, $heightHi)
  $matchHow = 'custom-hi'
  if ($RequireMediaMatch) {
    $names = ($probe.PaperSizes | ForEach-Object { $_.PaperName }) -join '; '
    throw "Media 62mm continua no encontrada en driver. Pedido='$MediaName'. Disponibles: $names"
  }
}

if ($paperSize.PaperName -match '29\s*mm\s*x\s*90' -or ($paperSize.PaperName -match '29\s*mm' -and $paperSize.PaperName -match '90')) {
  throw "Abortado: paper resuelto a '$($paperSize.PaperName)' (29x90). Fuerza form 62mm continua en el driver Brother."
}

$script:titleText = $Title
$script:bodyText = $Body
$script:footerText = $Footer
$script:pngImage = $null
$script:pngStream = $null
$script:printableInfo = $null

if ($PngPath -and (Test-Path -LiteralPath $PngPath)) {
  $script:pngImage = [System.Drawing.Image]::FromFile((Resolve-Path -LiteralPath $PngPath))
}
elseif ($PngBase64) {
  $raw = $PngBase64.Trim()
  if ($raw -match '^data:image/[^;]+;base64,(.+)$') {
    $raw = $Matches[1]
  }
  $bytes = [Convert]::FromBase64String($raw)
  $ms = New-Object System.IO.MemoryStream(, $bytes)
  $script:pngImage = [System.Drawing.Image]::FromStream($ms)
  $script:pngStream = $ms
}

$printPageHandler = {
  param($sender, $e)

  if ($null -ne $script:pngImage) {
    # El origen de Graphics es la esquina del AREA IMPRIMIBLE (no de la pagina fisica).
    # Dibujar sobre PageBounds corre la imagen HardMargin a la derecha/abajo y la recorta
    # (boleto "chueco"). Ajustamos el PNG dentro del area imprimible, centrado y sin deformar.
    $pa = $e.PageSettings.PrintableArea
    $areaW = [double]$pa.Width
    $areaH = [double]$pa.Height
    if ($areaW -le 0 -or $areaH -le 0) { $areaW = [double]$e.PageBounds.Width; $areaH = [double]$e.PageBounds.Height }
    $imgW = [double]$script:pngImage.Width
    $imgH = [double]$script:pngImage.Height
    $scale = [Math]::Min($areaW / $imgW, $areaH / $imgH)
    $drawW = $imgW * $scale
    $drawH = $imgH * $scale
    $x = ($areaW - $drawW) / 2.0
    $y = ($areaH - $drawH) / 2.0
    $script:printableInfo = @{ w = [Math]::Round($areaW); h = [Math]::Round($areaH); hardX = [Math]::Round([double]$e.PageSettings.HardMarginX); hardY = [Math]::Round([double]$e.PageSettings.HardMarginY); drawW = [Math]::Round($drawW); drawH = [Math]::Round($drawH) }
    $e.Graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $e.Graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $dest = New-Object System.Drawing.RectangleF([single]$x, [single]$y, [single]$drawW, [single]$drawH)
    $e.Graphics.DrawImage($script:pngImage, $dest)
    $e.HasMorePages = $false
    return
  }

  $bounds = $e.MarginBounds
  if ($bounds.Width -le 0 -or $bounds.Height -le 0) {
    $bounds = $e.PageBounds
    $bounds = New-Object System.Drawing.Rectangle(
      ($bounds.X + 8), ($bounds.Y + 8),
      [Math]::Max(8, $bounds.Width - 16),
      [Math]::Max(8, $bounds.Height - 16)
    )
  }

  $y = $bounds.Top
  $brush = [System.Drawing.Brushes]::Black
  $fontTitle = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
  $fontBody = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Regular)
  $fontFoot = New-Object System.Drawing.Font('Consolas', 7, [System.Drawing.FontStyle]::Regular)

  try {
    $e.Graphics.DrawString($script:titleText, $fontTitle, $brush, $bounds.Left, $y)
    $y += [int]($fontTitle.GetHeight($e.Graphics) + 4)

    if ($script:bodyText) {
      foreach ($line in ($script:bodyText -split "`n")) {
        $e.Graphics.DrawString($line, $fontBody, $brush, $bounds.Left, $y)
        $y += [int]($fontBody.GetHeight($e.Graphics) + 1)
        if ($y -gt ($bounds.Bottom - 18)) { break }
      }
    }

    if ($script:footerText) {
      $fh = $fontFoot.GetHeight($e.Graphics)
      $e.Graphics.DrawString(
        $script:footerText,
        $fontFoot,
        $brush,
        $bounds.Left,
        [Math]::Max($y + 2, $bounds.Bottom - $fh - 2)
      )
    }
  }
  finally {
    $fontTitle.Dispose()
    $fontBody.Dispose()
    $fontFoot.Dispose()
  }

  $e.HasMorePages = $false
}

function New-LabelDocument {
  # El "Tipo de papel" ya viene en el DEVMODE default del driver (Set-WindowsColorMode).
  # No tocar PageSettings.Color: el driver es mono para GDI y lo ignoraria o lo pisaria.
  $doc = New-Object System.Drawing.Printing.PrintDocument
  $doc.PrinterSettings.PrinterName = $PrinterName
  $doc.DocumentName = $JobName
  $doc.OriginAtMargins = $false
  $doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins 0, 0, 0, 0
  $doc.DefaultPageSettings.Landscape = $false
  $doc.DefaultPageSettings.PaperSize = $paperSize
  $doc.PrinterSettings.DefaultPageSettings.PaperSize = $paperSize
  $doc.add_PrintPage($printPageHandler)
  return $doc
}

# ---------------------------------------------------------------------------
# Intentos: modo recordado -> default Windows -> el otro
# ---------------------------------------------------------------------------

$state = Read-BridgeState
$remembered = $null
if ($state.printers.ContainsKey($PrinterName)) { $remembered = $state.printers[$PrinterName].colorMode }
if ($remembered -and $remembered -notin @('mono', 'redblack')) { $remembered = $null }
$windowsMode = Get-WindowsColorMode -Printer $PrinterName

$plan = Resolve-ModeOrder -Requested $ColorMode -Remembered $remembered -WindowsDefault $windowsMode -AllowRetry (-not $NoRetry)
$attempts = New-Object System.Collections.ArrayList
$finalMode = $null
$finalSource = $null
$finalWatch = $null
$failure = $null
$currentWindowsMode = $windowsMode
$syncedWindows = $false

Write-Log "job=$JobName paper='$($paperSize.PaperName)' W=$($paperSize.Width) H=$($paperSize.Height) how=$matchHow plan=$($plan.Order -join '>') remembered=$remembered windows=$windowsMode"

try {
  foreach ($mode in $plan.Order) {
    if ($currentWindowsMode -ne $mode) {
      if (Set-WindowsColorMode -Printer $PrinterName -Mode $mode) {
        $currentWindowsMode = $mode
        $syncedWindows = $true
      }
      else {
        [void]$attempts.Add(@{ mode = $mode; source = $plan.Sources[$mode]; result = 'skipped'; status = 'no se pudo fijar Tipo de papel en el driver'; jobId = $null })
        $failure = "No se pudo fijar Tipo de papel=$mode en el driver Brother."
        continue
      }
    }
    $before = Get-QueueIds -Printer $PrinterName
    $doc = New-LabelDocument
    try {
      Write-Log "intento modo=$mode ($($plan.Sources[$mode]))"
      $doc.Print()
    }
    finally {
      $doc.Dispose()
    }

    $watch = Watch-SpoolJob -Printer $PrinterName -ExistingIds $before -JobPrefix $JobName -Seconds $WatchSeconds
    [void]$attempts.Add(@{ mode = $mode; source = $plan.Sources[$mode]; result = $watch.Result; status = $watch.Status; jobId = $watch.JobId })
    Write-Log "modo=$mode -> $($watch.Result) [$($watch.Status)]"

    if ($watch.Result -eq 'error') {
      $removed = $false
      if ($watch.JobId) { $removed = Remove-SpoolJob -Printer $PrinterName -JobId $watch.JobId }
      if (-not $removed) {
        $failure = "La Brother rechazo el job (modo $mode, estado '$($watch.Status)') y no se pudo cancelar el trabajo $($watch.JobId). Cancelalo en la cola de impresion de Windows y reintenta."
        break
      }
      $failure = "La Brother rechazo el job en modo $mode (estado '$($watch.Status)')."
      continue
    }

    # printed o timeout sin error = enviado
    $finalMode = $mode
    $finalSource = $plan.Sources[$mode]
    $finalWatch = $watch
    $failure = $null
    break
  }
}
finally {
  if ($null -ne $script:pngImage) { $script:pngImage.Dispose() }
  if ($null -ne $script:pngStream) { $script:pngStream.Dispose() }
}

if (-not $finalMode) {
  $tried = ($plan.Order -join ' y ')
  $msg = "No se imprimio. $failure Modos probados: $tried. Revisa: rollo 62 mm cinta continua cargado (monocromo o negro/rojo), tapa cerrada, sin atasco, USB conectado."
  Write-Error $msg
  exit 1
}

# Recordar modo que funciono (el default de Windows ya quedo en ese modo: Chrome / P-touch coinciden)
if ($finalWatch.Result -eq 'printed' -or $finalWatch.Result -eq 'timeout') {
  $state.printers[$PrinterName] = @{
    colorMode = $finalMode
    paper     = $paperSize.PaperName
    updatedAt = (Get-Date).ToString('o')
  }
  Save-BridgeState -State $state
}

Write-Output (@{
  ok              = $true
  printer         = $PrinterName
  paper           = $paperSize.PaperName
  paperWidthHi    = $paperSize.Width
  paperHeightHi   = $paperSize.Height
  matchHow        = $matchHow
  documentName    = $JobName
  mode            = $(if ($PngPath -or $PngBase64) { 'png' } else { 'text' })
  colorMode       = $finalMode
  colorModeSource = $finalSource
  watched         = $finalWatch.Result
  jobStatus       = $finalWatch.Status
  jobId           = $finalWatch.JobId
  attempts        = @($attempts)
  windowsSynced   = $syncedWindows
  printable       = $script:printableInfo
} | ConvertTo-Json -Compress -Depth 5)
