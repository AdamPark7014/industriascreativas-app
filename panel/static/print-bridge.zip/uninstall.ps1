﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Desinstala el agente de impresion ExperienceBT (Brother QL-800) del usuario actual.
.DESCRIPTION
  Detiene el agente, quita el acceso directo de Inicio y borra
  %LOCALAPPDATA%\ExperienceBT\print-bridge\app. Conserva state.json (rollo detectado) y agent.log.
  No toca el driver Brother ni la impresora de Windows.
#>
[CmdletBinding()]
param(
  # Puerto del agente. 0 = PORT de .env instalado o 9631.
  [int]$Port = 0
)

$ErrorActionPreference = 'Stop'

$StateDir = Join-Path $env:LOCALAPPDATA 'ExperienceBT\print-bridge'
$AppDir = Join-Path $StateDir 'app'
$PidPath = Join-Path $StateDir 'agent.pid'
$StartupDir = [Environment]::GetFolderPath('Startup')
$ShortcutPath = Join-Path $StartupDir 'ExperienceBT Impresora QL.lnk'

function Write-Step { param([string]$Msg) Write-Host "[desinstalar] $Msg" -ForegroundColor Cyan }
function Write-Ok { param([string]$Msg) Write-Host "[desinstalar] $Msg" -ForegroundColor Green }
function Write-Warn2 { param([string]$Msg) Write-Host "[desinstalar] AVISO: $Msg" -ForegroundColor Yellow }

function Read-DotEnvValue {
  param([string]$Path, [string]$Key)
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  foreach ($line in @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
    $t = ('' + $line).Trim()
    if (-not $t -or $t.StartsWith('#')) { continue }
    $eq = $t.IndexOf('=')
    if ($eq -le 0) { continue }
    if ($t.Substring(0, $eq).Trim() -ne $Key) { continue }
    $v = $t.Substring($eq + 1).Trim()
    if ($v.Length -ge 2 -and (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'")))) {
      $v = $v.Substring(1, $v.Length - 2)
    }
    return $v
  }
  return $null
}

function Get-AncestorPids {
  # PIDs de este proceso y de toda su cadena de padres: nunca se detienen.
  $set = @{}
  try {
    $all = @{}
    foreach ($p in (Get-CimInstance Win32_Process -ErrorAction Stop)) { $all[[int]$p.ProcessId] = [int]$p.ParentProcessId }
    $cur = [int]$PID
    $hops = 0
    while ($cur -gt 0 -and -not $set.ContainsKey($cur) -and $hops -lt 64) {
      $set[$cur] = $true
      if (-not $all.ContainsKey($cur)) { break }
      $cur = $all[$cur]
      $hops++
    }
  }
  catch { $set[[int]$PID] = $true }
  return $set
}

function Get-AgentProcesses {
  # powershell.exe / pwsh.exe lanzados con "-File ...\agent.ps1" (agente oculto o start.cmd).
  $list = @()
  $ancestors = Get-AncestorPids
  try {
    $procs = Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe' OR Name = 'pwsh.exe'" -ErrorAction Stop
    foreach ($p in $procs) {
      $procId = [int]$p.ProcessId
      if ($ancestors.ContainsKey($procId)) { continue }
      if (('' + $p.CommandLine) -match '(?i)-File\s+"?[^"]*\\agent\.ps1"?(\s|$)') { $list += $procId }
    }
  }
  catch { }
  return @($list)
}

Write-Host ''
Write-Host '=== ExperienceBT - Desinstalar agente de impresora QL-800 ===' -ForegroundColor White

if ($Port -le 0) {
  $envPort = Read-DotEnvValue -Path (Join-Path $AppDir '.env') -Key 'PORT'
  $parsed = 0
  if ($envPort -and [int]::TryParse($envPort, [ref]$parsed) -and $parsed -gt 0) { $Port = $parsed } else { $Port = 9631 }
}

# 1. Detener agentes (el del puerto y cualquier agent.ps1)
$stopped = @()
$owners = @()
try {
  $owners = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop | ForEach-Object { [int]$_.OwningProcess } | Sort-Object -Unique)
}
catch { $owners = @() }
$ancestors = Get-AncestorPids
foreach ($ownerPid in $owners) {
  if ($ownerPid -le 4) { continue }
  if ($ancestors.ContainsKey([int]$ownerPid)) { continue }
  try {
    $p = Get-Process -Id $ownerPid -ErrorAction Stop
    if ($p.ProcessName -in @('node', 'powershell', 'pwsh', 'wscript')) {
      Write-Step "deteniendo $($p.ProcessName) (PID $ownerPid) en el puerto $Port"
      Stop-Process -Id $ownerPid -Force -ErrorAction Stop
      $stopped += $ownerPid
    }
  }
  catch { Write-Warn2 "no se pudo detener PID ${ownerPid}: $($_.Exception.Message)" }
}
foreach ($agentPid in (Get-AgentProcesses)) {
  if ($stopped -contains $agentPid) { continue }
  try {
    Write-Step "deteniendo agente PowerShell (PID $agentPid)"
    Stop-Process -Id $agentPid -Force -ErrorAction Stop
    $stopped += $agentPid
  }
  catch { Write-Warn2 "no se pudo detener PID ${agentPid}: $($_.Exception.Message)" }
}
if ($stopped.Count -eq 0) { Write-Step 'no habia ningun agente en ejecucion' }
Start-Sleep -Milliseconds 500
Remove-Item -LiteralPath $PidPath -Force -ErrorAction SilentlyContinue

# 2. Acceso directo de Inicio
if (Test-Path -LiteralPath $ShortcutPath) {
  Remove-Item -LiteralPath $ShortcutPath -Force
  Write-Step "quitado el acceso directo de Inicio: $ShortcutPath"
}
else {
  Write-Step 'no habia acceso directo en Inicio'
}

# 3. Carpeta app (conserva state.json y agent.log en la carpeta padre)
if (Test-Path -LiteralPath $AppDir) {
  $removed = $false
  for ($i = 0; $i -lt 5 -and -not $removed; $i++) {
    try {
      Remove-Item -LiteralPath $AppDir -Recurse -Force -ErrorAction Stop
      $removed = $true
    }
    catch {
      Start-Sleep -Milliseconds 600
    }
  }
  if ($removed) {
    Write-Step "borrada la carpeta $AppDir"
  }
  else {
    # Si este mismo script corre desde la carpeta app, cmd.exe puede tenerla en uso: borrar en diferido.
    Write-Warn2 "no se pudo borrar $AppDir ahora; se borrara en unos segundos"
    $cmd = 'ping -n 4 127.0.0.1 >nul & rmdir /s /q "' + $AppDir + '"'
    Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\cmd.exe') -ArgumentList ('/c ' + $cmd) -WindowStyle Hidden | Out-Null
  }
}
else {
  Write-Step 'la carpeta app no existia'
}

Write-Host ''
Write-Ok 'Agente desinstalado. Se conservan state.json y agent.log en:'
Write-Host "  $StateDir"
Write-Host 'El driver Brother y la impresora de Windows no se han tocado.'
Write-Host ''
exit 0
