@echo off
REM One-click: agente local QL-800 en esta laptop (USB + driver Brother).
REM Doble clic o: tools\print-bridge\start.cmd
cd /d "%~dp0"
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" -OpenBrowser
if errorlevel 1 (
  echo.
  echo Si pwsh no existe, prueba: powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" -OpenBrowser
  pause
)
