@echo off
REM Agente local QL-800 VISIBLE (depuracion): deja esta ventana abierta y muestra el log.
REM Uso normal: doble clic en Instalar-Impresora-QL.cmd (agente oculto + arranque con Windows).
REM Solo necesita Windows PowerShell 5.1 (viene con Windows). Sin Node, sin admin.
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0agent.ps1" -OpenBrowser %*
if errorlevel 1 (
  echo.
  echo El agente termino con error. Revisa el log: %LOCALAPPDATA%\ExperienceBT\print-bridge\agent.log
  pause
)
