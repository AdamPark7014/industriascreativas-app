/**
 * Puente local de impresión para ExperienceBT (cualquier laptop del operador).
 *
 * Escucha solo en 127.0.0.1 por defecto — no expuesto a Hetzner.
 * Auto-detecta Brother QL-800 en el spooler Windows si PRINTER_NAME está vacío
 * o no coincide con ninguna impresora instalada.
 *
 * Env:
 *   PORT=9631
 *   BIND=127.0.0.1
 *   PRINTER_NAME=                 # opcional; vacío = auto-detect
 *   PRINTER_HOST=                 # opcional: Epson térmica Ethernet
 *   PRINTER_PORT=9100
 *   LABEL_WIDTH_MM=62
 *   LABEL_HEIGHT_MM=100
 *   LABEL_MEDIA_NAME=62mm Cinta continua
 *   PRINT_BRIDGE_TOKEN=           # opcional; si se define, exige header Authorization
 *
 * Endpoints:
 *   GET  /health
 *   GET  /printers
 *   POST /print          raw ESC/POS → TCP 9100 (si PRINTER_HOST)
 *   POST /print-label    JSON → GDI Windows (QL-800)
 *   POST /test           etiqueta de prueba
 */

import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { createConnection } from 'node:net';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { readFileSync, existsSync, writeFileSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { randomBytes } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

const POWERSHELL =
  process.env.POWERSHELL_PATH ||
  (process.platform === 'win32'
    ? `${process.env.SystemRoot || 'C:\\Windows'}\\System32\\WindowsPowerShell\\v1.0\\powershell.exe`
    : 'powershell');

const __dirname = dirname(fileURLToPath(import.meta.url));

function loadDotEnv() {
  const envPath = join(__dirname, '.env');
  if (!existsSync(envPath)) return;
  for (const line of readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq <= 0) continue;
    const key = trimmed.slice(0, eq).trim();
    let val = trimmed.slice(eq + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = val;
  }
}

loadDotEnv();

const PORT = Number(process.env.PORT || 9631);
const BIND = process.env.BIND || '127.0.0.1';
const PRINTER_NAME_ENV = (process.env.PRINTER_NAME || '').trim();
const PRINTER_HOST = (process.env.PRINTER_HOST || '').trim();
const PRINTER_PORT = Number(process.env.PRINTER_PORT || 9100);
const LABEL_WIDTH_MM = Number(process.env.LABEL_WIDTH_MM || 62);
const LABEL_HEIGHT_MM = Number(process.env.LABEL_HEIGHT_MM || 100);
const LABEL_MEDIA_NAME = (process.env.LABEL_MEDIA_NAME || '62mm Cinta continua').trim();
const PRINT_BRIDGE_TOKEN = (process.env.PRINT_BRIDGE_TOKEN || '').trim();

const JOB_NAME = 'ExperienceBT-QL-62x100';

const ALLOWED_ORIGIN_RE =
  /^(https:\/\/(panel|demo)\.experiencebt\.com\.mx|http:\/\/(localhost|127\.0\.0\.1)(:\d+)?)$/i;

function corsHeaders(req) {
  const origin = String(req?.headers?.origin || '').trim();
  const allow =
    !origin || ALLOWED_ORIGIN_RE.test(origin)
      ? origin || '*'
      : 'https://panel.experiencebt.com.mx';
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'content-type, authorization',
    Vary: 'Origin',
  };
}

/** Preferencia: Brother QL-800 exacto → cualquier QL-800 → null. */
export function pickQl800(printers) {
  const list = Array.isArray(printers) ? printers : [];
  const brother = list.find((n) => /Brother\s*QL-?800/i.test(String(n)));
  if (brother) return brother;
  const ql = list.find((n) => /QL-?800/i.test(String(n)));
  return ql || null;
}

/**
 * Resuelve impresora activa.
 * 1) override (UI / body) si está en la lista
 * 2) PRINTER_NAME env si no vacío y está listada
 * 3) auto-detect Brother QL-800 / QL-800
 */
export function resolvePrinterName(printers, override) {
  const list = Array.isArray(printers) ? printers : [];
  const wanted = (override || '').trim();
  if (wanted && list.includes(wanted)) {
    return { name: wanted, source: 'override' };
  }
  if (PRINTER_NAME_ENV && list.includes(PRINTER_NAME_ENV)) {
    return { name: PRINTER_NAME_ENV, source: 'env' };
  }
  const auto = pickQl800(list);
  if (auto) {
    return {
      name: auto,
      source:
        PRINTER_NAME_ENV && !list.includes(PRINTER_NAME_ENV)
          ? 'auto-fallback'
          : 'auto',
    };
  }
  return { name: null, source: 'none' };
}

function json(res, status, body, req) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    ...corsHeaders(req),
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
  });
  res.end(payload);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function mmToHmm(mm) {
  return Math.round(mm * 100);
}

function authOk(req) {
  if (!PRINT_BRIDGE_TOKEN) return true;
  const header = req.headers.authorization || '';
  if (header === `Bearer ${PRINT_BRIDGE_TOKEN}`) return true;
  if (header === PRINT_BRIDGE_TOKEN) return true;
  return false;
}

async function probeTcp() {
  if (!PRINTER_HOST) return { configured: false, reachable: false };
  return new Promise((resolve) => {
    const socket = createConnection({ host: PRINTER_HOST, port: PRINTER_PORT });
    const timer = setTimeout(() => {
      socket.destroy();
      resolve({ configured: true, reachable: false });
    }, 2500);
    socket.on('connect', () => {
      clearTimeout(timer);
      socket.end();
      resolve({ configured: true, reachable: true });
    });
    socket.on('error', () => {
      clearTimeout(timer);
      resolve({ configured: true, reachable: false });
    });
  });
}

async function listWindowsPrinters() {
  if (process.platform !== 'win32') return [];
  try {
    const { stdout } = await execFileAsync(
      POWERSHELL,
      [
        '-NoProfile',
        '-NonInteractive',
        '-Command',
        'Get-Printer | Select-Object -ExpandProperty Name | ConvertTo-Json -Compress',
      ],
      { windowsHide: true, timeout: 8000 },
    );
    const parsed = JSON.parse(stdout.trim() || '[]');
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return [];
  }
}

function printLabelWindows({
  printerName,
  title,
  body,
  footer,
  widthMm,
  heightMm,
  mediaName,
  pngBase64,
  jobName,
}) {
  return new Promise((resolve, reject) => {
    if (process.platform !== 'win32') {
      reject(new Error('Impresión Windows solo disponible en win32'));
      return;
    }
    if (!printerName) {
      reject(
        new Error(
          'No hay impresora QL-800. Instala el driver Brother, conecta USB y reinicia el agente (o elige una en la UI).',
        ),
      );
      return;
    }

    let pngPath = '';
    if (pngBase64) {
      try {
        const buf = Buffer.from(String(pngBase64).replace(/\s/g, ''), 'base64');
        pngPath = join(tmpdir(), `ql-label-${randomBytes(8).toString('hex')}.png`);
        writeFileSync(pngPath, buf);
      } catch (err) {
        reject(err instanceof Error ? err : new Error(String(err)));
        return;
      }
    }

    const script = join(__dirname, 'print-label.ps1');
    const args = [
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      script,
      '-PrinterName',
      printerName,
      '-JobName',
      jobName || JOB_NAME,
      '-Title',
      title,
      '-Body',
      body || '',
      '-Footer',
      footer || '',
      '-WidthHmm',
      String(mmToHmm(widthMm ?? LABEL_WIDTH_MM)),
      '-HeightHmm',
      String(mmToHmm(heightMm ?? LABEL_HEIGHT_MM)),
    ];
    if (mediaName || LABEL_MEDIA_NAME) {
      args.push('-MediaName', mediaName || LABEL_MEDIA_NAME);
    }
    if (pngPath) {
      args.push('-PngPath', pngPath);
    }
    args.push('-RequireMediaMatch');

    const cleanup = () => {
      if (!pngPath) return;
      try {
        unlinkSync(pngPath);
      } catch {
        /* ignore */
      }
    };

    const resolvedJob = jobName || JOB_NAME;
    console.log(
      `[print-bridge] print job=${resolvedJob} printer=${printerName} media=${mediaName || LABEL_MEDIA_NAME || '62mm'} png=${Boolean(pngPath)}`,
    );

    const ps = spawn(POWERSHELL, args, { windowsHide: true });
    let stdout = '';
    let stderr = '';
    ps.stdout.on('data', (d) => {
      stdout += d.toString();
    });
    ps.stderr.on('data', (d) => {
      stderr += d.toString();
    });
    ps.on('close', (code) => {
      cleanup();
      const out = stdout.trim();
      const err = stderr.trim();
      let parsed = null;
      try {
        const jsonLine = out
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter(Boolean)
          .reverse()
          .find((l) => l.startsWith('{'));
        if (jsonLine) parsed = JSON.parse(jsonLine);
      } catch {
        /* ignore parse */
      }
      if (code === 0) {
        const paper = parsed?.paper || null;
        console.log(
          `[print-bridge] OK job=${resolvedJob} paper=${paper || '(unknown)'} how=${parsed?.matchHow || '?'}`,
        );
        resolve({
          ok: true,
          via: 'windows',
          printer: printerName,
          documentName: resolvedJob,
          paper,
          paperWidthHi: parsed?.paperWidthHi ?? null,
          paperHeightHi: parsed?.paperHeightHi ?? null,
          matchHow: parsed?.matchHow || null,
          mode: parsed?.mode || (pngPath ? 'png' : 'text'),
          stdout: out,
        });
        return;
      }
      const msg =
        err ||
        parsed?.error ||
        out ||
        `PowerShell exit ${code} (impresión fallida; no se usó Chrome)`;
      console.error(`[print-bridge] FAIL job=${resolvedJob}: ${msg}`);
      reject(new Error(msg));
    });
    ps.on('error', (err) => {
      cleanup();
      reject(err);
    });
  });
}

function printRawTcp(bytes) {
  return new Promise((resolve, reject) => {
    if (!PRINTER_HOST) {
      reject(new Error('PRINTER_HOST no configurado (modo TCP ESC/POS)'));
      return;
    }
    const socket = createConnection({ host: PRINTER_HOST, port: PRINTER_PORT });
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error(`Timeout conectando a ${PRINTER_HOST}:${PRINTER_PORT}`));
    }, 8000);
    socket.on('connect', () => {
      socket.write(bytes, (err) => {
        clearTimeout(timer);
        if (err) {
          socket.destroy();
          reject(err);
          return;
        }
        socket.end();
        resolve({ ok: true, via: 'tcp', bytes: bytes.length });
      });
    });
    socket.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

async function buildPrinterStatus(override) {
  const printers = await listWindowsPrinters();
  const resolved = resolvePrinterName(printers, override);
  const tcp = await probeTcp();
  const namedOk = Boolean(resolved.name && printers.includes(resolved.name));
  const qlHints = printers.filter(
    (n) =>
      /brother|ql|epson|label|térmic|termic/i.test(n) ||
      n === resolved.name ||
      n === PRINTER_NAME_ENV,
  );
  return {
    printers,
    qlHints,
    resolved,
    namedOk,
    tcp,
    reachable: namedOk || tcp.reachable,
    mode: resolved.name ? 'windows' : tcp.configured ? 'tcp' : 'none',
  };
}

const server = createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, corsHeaders(req));
    res.end();
    return;
  }

  if (!authOk(req)) {
    json(res, 401, { ok: false, error: 'Token inválido (PRINT_BRIDGE_TOKEN)' }, req);
    return;
  }

  const url = new URL(req.url || '/', `http://${BIND}:${PORT}`);

  try {
    if (req.method === 'GET' && url.pathname === '/health') {
      const status = await buildPrinterStatus(url.searchParams.get('printer') || '');
      json(
        res,
        200,
        {
          ok: true,
          reachable: status.reachable,
          mode: status.mode,
          printerName: status.resolved.name,
          printerSource: status.resolved.source,
          printerEnv: PRINTER_NAME_ENV || null,
          printerHost: PRINTER_HOST || null,
          printerListed: status.namedOk,
          authRequired: Boolean(PRINT_BRIDGE_TOKEN),
          jobName: JOB_NAME,
          label: {
            widthMm: LABEL_WIDTH_MM,
            heightMm: LABEL_HEIGHT_MM,
            mediaName: LABEL_MEDIA_NAME || null,
          },
          printers: status.qlHints,
          printersAll: status.printers,
        },
        req,
      );
      return;
    }

    if (req.method === 'GET' && url.pathname === '/printers') {
      const status = await buildPrinterStatus(url.searchParams.get('printer') || '');
      json(
        res,
        200,
        {
          ok: true,
          printers: status.printers,
          preferred: status.qlHints,
          selected: status.resolved.name,
          source: status.resolved.source,
          printerEnv: PRINTER_NAME_ENV || null,
        },
        req,
      );
      return;
    }

    if (req.method === 'POST' && url.pathname === '/print') {
      const body = await readBody(req);
      if (!body.length) {
        json(res, 400, { ok: false, error: 'Cuerpo vacío' }, req);
        return;
      }
      if (PRINTER_HOST) {
        const result = await printRawTcp(body);
        json(res, 200, result, req);
        return;
      }
      json(
        res,
        400,
        {
          ok: false,
          error:
            'POST /print es ESC/POS crudo (Ethernet 9100). Para Brother QL-800 usa POST /test o /print-label. Configura PRINTER_HOST solo para térmicas Epson.',
        },
        req,
      );
      return;
    }

    if (req.method === 'POST' && (url.pathname === '/print-label' || url.pathname === '/test')) {
      let payload = {};
      const raw = await readBody(req);
      if (raw.length) {
        try {
          payload = JSON.parse(raw.toString('utf8'));
        } catch {
          json(res, 400, { ok: false, error: 'JSON inválido' }, req);
          return;
        }
      }

      const override = (payload.printerName || payload.printer || '').trim();
      const status = await buildPrinterStatus(override);
      const printerName = status.resolved.name;

      const now = new Date().toLocaleString('es-MX');
      const title =
        payload.title ||
        (url.pathname === '/test' ? 'EXPERIENCEBT · PRUEBA' : 'EXPERIENCEBT');
      const body =
        payload.body ||
        (url.pathname === '/test'
          ? `Etiqueta de prueba\n${now}\nImpresora: ${printerName || '(sin nombre)'}`
          : '');
      const footer = payload.footer || 'QL local · no prod Hetzner';

      const pngBase64 = String(
        payload.pngBase64 || payload.imageBase64 || payload.png || '',
      )
        .replace(/^data:image\/\w+;base64,/, '')
        .trim();

      const result = await printLabelWindows({
        printerName,
        title,
        body,
        footer,
        widthMm: payload.widthMm ?? LABEL_WIDTH_MM,
        heightMm: payload.heightMm ?? LABEL_HEIGHT_MM,
        mediaName: payload.mediaName || LABEL_MEDIA_NAME,
        pngBase64: pngBase64 || undefined,
        jobName: JOB_NAME,
      });
      json(
        res,
        200,
        {
          ...result,
          printer: printerName,
          printerSource: status.resolved.source,
          jobName: JOB_NAME,
          mediaName: payload.mediaName || LABEL_MEDIA_NAME,
          widthMm: payload.widthMm ?? LABEL_WIDTH_MM,
          heightMm: payload.heightMm ?? LABEL_HEIGHT_MM,
        },
        req,
      );
      return;
    }

    json(res, 404, { ok: false, error: 'Not found' }, req);
  } catch (err) {
    json(
      res,
      500,
      {
        ok: false,
        error: err instanceof Error ? err.message : String(err),
      },
      req,
    );
  }
});

server.listen(PORT, BIND, async () => {
  console.log(`[print-bridge] http://${BIND}:${PORT}`);
  console.log(
    `[print-bridge] PRINTER_NAME env=${PRINTER_NAME_ENV || '(vacío → auto-detect)'}`,
  );
  console.log(
    `[print-bridge] label ${LABEL_WIDTH_MM}×${LABEL_HEIGHT_MM} mm · media=${LABEL_MEDIA_NAME || '(auto)'}`,
  );
  if (PRINT_BRIDGE_TOKEN) {
    console.log('[print-bridge] PRINT_BRIDGE_TOKEN activo (Authorization requerido)');
  }
  if (PRINTER_HOST) {
    console.log(`[print-bridge] TCP ESC/POS ${PRINTER_HOST}:${PRINTER_PORT}`);
  }
  try {
    const status = await buildPrinterStatus('');
    console.log(
      `[print-bridge] resuelto=${status.resolved.name || '(ninguna)'} · fuente=${status.resolved.source} · instaladas=${status.printers.length}`,
    );
  } catch (err) {
    console.warn(
      `[print-bridge] no se pudo listar impresoras: ${err instanceof Error ? err.message : err}`,
    );
  }
});
