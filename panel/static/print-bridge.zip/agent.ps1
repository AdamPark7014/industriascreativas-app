﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Agente local de impresion ExperienceBT para Brother QL-800. Solo Windows PowerShell 5.1: sin Node, sin admin.
.DESCRIPTION
  Servidor HTTP en 127.0.0.1:9631 (System.Net.HttpListener). Mismo contrato que server.mjs:

    OPTIONS *            preflight CORS (Access-Control-Allow-Private-Network: true)
    GET  /health         estado, impresora resuelta, modo de color recordado
    GET  /printers       impresoras Windows + seleccionada
    POST /test           etiqueta de prueba
    POST /print-label    etiqueta (texto o PNG base64) -> print-label.ps1 -> spooler -> USB
    POST /print          no soportado aqui (ESC/POS por red solo en server.mjs)

  Lee .env junto al script si existe: PORT, BIND, PRINTER_NAME, LABEL_WIDTH_MM, LABEL_HEIGHT_MM,
  LABEL_MEDIA_NAME, PRINT_BRIDGE_TOKEN. Los parametros -Port / -Bind mandan sobre .env.

  Cada impresion corre print-label.ps1 en un powershell.exe hijo; las peticiones rapidas (/health)
  se siguen atendiendo mientras se imprime. Las impresiones se encolan de una en una.

  Log: %LOCALAPPDATA%\ExperienceBT\print-bridge\agent.log (rota a agent.log.1 al pasar de 1 MB).
  Si el puerto ya esta ocupado (otra instancia, o el puente Node) termina con codigo 0.

.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\agent.ps1
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\agent.ps1 -Port 9641 -OpenBrowser
#>
[CmdletBinding()]
param(
  # Puerto de escucha. 0 = PORT de .env o 9631.
  [int]$Port = 0,

  # Direccion de escucha. Vacio = BIND de .env o 127.0.0.1.
  [string]$Bind = '',

  # Abre /health en el navegador al arrancar (depuracion).
  [switch]$OpenBrowser
)

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# Constantes y rutas
# ---------------------------------------------------------------------------

$script:Version = '0.3.1'
$script:JobName = 'ExperienceBT-QL-62x100'
$script:Root = $PSScriptRoot
$script:PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$script:PrintScript = Join-Path $script:Root 'print-label.ps1'
$script:StateDir = Join-Path $env:LOCALAPPDATA 'ExperienceBT\print-bridge'
$script:AppDir = Join-Path $script:StateDir 'app'
$script:LogPath = Join-Path $script:StateDir 'agent.log'
$script:StatePath = Join-Path $script:StateDir 'state.json'
$script:PidPath = Join-Path $script:StateDir 'agent.pid'
$script:StartedAt = Get-Date
$script:Installed = ($script:Root.TrimEnd('\') -ieq $script:AppDir.TrimEnd('\'))
$script:AllowedOriginRe = '^(https://(panel|demo)\.experiencebt\.com\.mx|http://(localhost|127\.0\.0\.1)(:\d+)?)$'
$script:PrintTimeoutSec = 180

# ---------------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------------

function Write-AgentLog {
  param([string]$Message, [string]$Level = 'INFO')
  $line = '{0} [{1}] {2}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Level, $Message
  try { Write-Host $line } catch { }
  try {
    if (-not (Test-Path -LiteralPath $script:StateDir)) {
      New-Item -ItemType Directory -Force -Path $script:StateDir | Out-Null
    }
    $fi = Get-Item -LiteralPath $script:LogPath -ErrorAction SilentlyContinue
    if ($fi -and $fi.Length -gt 1MB) {
      Move-Item -LiteralPath $script:LogPath -Destination ($script:LogPath + '.1') -Force
    }
    [IO.File]::AppendAllText($script:LogPath, $line + [Environment]::NewLine, [Text.Encoding]::UTF8)
  }
  catch { }
}

# ---------------------------------------------------------------------------
# Configuracion (.env junto al script, igual que server.mjs)
# ---------------------------------------------------------------------------

function Read-DotEnv {
  param([string]$Path)
  $map = @{}
  if (-not (Test-Path -LiteralPath $Path)) { return $map }
  foreach ($line in @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
    $t = ('' + $line).Trim()
    if (-not $t -or $t.StartsWith('#')) { continue }
    $eq = $t.IndexOf('=')
    if ($eq -le 0) { continue }
    $k = $t.Substring(0, $eq).Trim()
    $v = $t.Substring($eq + 1).Trim()
    if ($v.Length -ge 2) {
      if (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'"))) {
        $v = $v.Substring(1, $v.Length - 2)
      }
    }
    $map[$k] = $v
  }
  return $map
}

function Get-Setting {
  # Prioridad: variable de entorno del proceso > .env > valor por defecto.
  param([string]$Name, [string]$Default)
  $envVal = [Environment]::GetEnvironmentVariable($Name)
  if ($null -ne $envVal -and $envVal.Trim() -ne '') { return $envVal.Trim() }
  if ($script:DotEnv.ContainsKey($Name) -and $script:DotEnv[$Name] -ne '') { return $script:DotEnv[$Name] }
  return $Default
}

function ConvertTo-Number {
  param($Value, [double]$Default)
  if ($null -eq $Value) { return $Default }
  $s = ('' + $Value).Trim()
  if ($s -eq '') { return $Default }
  $out = 0.0
  if ([double]::TryParse($s, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$out)) {
    return $out
  }
  return $Default
}

$script:DotEnv = Read-DotEnv -Path (Join-Path $script:Root '.env')
if ($Port -le 0) { $Port = [int](ConvertTo-Number (Get-Setting 'PORT' '9631') 9631) }
if (-not $Bind) { $Bind = Get-Setting 'BIND' '127.0.0.1' }
$script:PrinterNameEnv = (Get-Setting 'PRINTER_NAME' '').Trim()
$script:LabelWidthMm = ConvertTo-Number (Get-Setting 'LABEL_WIDTH_MM' '62') 62
$script:LabelHeightMm = ConvertTo-Number (Get-Setting 'LABEL_HEIGHT_MM' '100') 100
$script:LabelMediaName = (Get-Setting 'LABEL_MEDIA_NAME' '62mm Cinta continua').Trim()
$script:Token = (Get-Setting 'PRINT_BRIDGE_TOKEN' '').Trim()

# ---------------------------------------------------------------------------
# Impresoras y estado
# ---------------------------------------------------------------------------

$script:PrinterCache = @{ At = [datetime]::MinValue; Names = @() }

function Get-WindowsPrinterNames {
  # Cache de 3 s: la UI sondea /health con frecuencia y Get-Printer no es gratis.
  $age = ((Get-Date) - $script:PrinterCache.At).TotalSeconds
  if ($age -lt 3 -and $script:PrinterCache.Names.Count -gt 0) { return @($script:PrinterCache.Names) }
  $names = @()
  try {
    $names = @(Get-Printer -ErrorAction Stop | ForEach-Object { [string]$_.Name })
  }
  catch {
    Write-AgentLog "Get-Printer fallo: $($_.Exception.Message)" 'WARN'
    $names = @()
  }
  $script:PrinterCache = @{ At = (Get-Date); Names = $names }
  return @($names)
}

function Get-PrinterOnline {
  # Windows acepta jobs con la impresora apagada (se quedan en cola en estado Normal).
  # Para el operador eso es "no imprime": consultamos WorkOffline / PrinterStatus por WMI.
  param([string]$Printer)
  if (-not $Printer) { return @{ online = $null; reason = 'sin impresora' } }
  try {
    $safe = $Printer -replace "'", "''"
    $w = Get-CimInstance Win32_Printer -Filter "Name='$safe'" -ErrorAction Stop
    if ($null -eq $w) { return @{ online = $null; reason = 'sin datos WMI' } }
    if ($w.WorkOffline) { return @{ online = $false; reason = 'apagada o USB desconectado (Windows: sin conexion)' } }
    if ([int]$w.PrinterStatus -eq 7) { return @{ online = $false; reason = 'estado Offline' } }
    return @{ online = $true; reason = ('PrinterStatus=' + $w.PrinterStatus) }
  }
  catch {
    return @{ online = $null; reason = ('WMI no disponible: ' + $_.Exception.Message) }
  }
}

function Select-Ql800 {
  # Preferencia: Brother QL-800 exacto -> cualquier QL-800 -> $null.
  param([string[]]$Printers)
  foreach ($n in $Printers) { if ($n -match 'Brother\s*QL-?800') { return $n } }
  foreach ($n in $Printers) { if ($n -match 'QL-?800') { return $n } }
  return $null
}

function Resolve-PrinterName {
  # 1) override (UI / body) si esta instalada  2) PRINTER_NAME de .env si esta instalada  3) auto-detect QL-800
  param([string[]]$Printers, [string]$Override)
  $wanted = ('' + $Override).Trim()
  if ($wanted -and ($Printers -contains $wanted)) { return @{ name = $wanted; source = 'override' } }
  if ($script:PrinterNameEnv -and ($Printers -contains $script:PrinterNameEnv)) {
    return @{ name = $script:PrinterNameEnv; source = 'env' }
  }
  $auto = Select-Ql800 -Printers $Printers
  if ($auto) {
    $source = 'auto'
    if ($script:PrinterNameEnv -and -not ($Printers -contains $script:PrinterNameEnv)) { $source = 'auto-fallback' }
    return @{ name = $auto; source = $source }
  }
  return @{ name = $null; source = 'none' }
}

function Get-PrinterStatus {
  param([string]$Override)
  $printers = Get-WindowsPrinterNames
  $resolved = Resolve-PrinterName -Printers $printers -Override $Override
  $namedOk = [bool]($resolved.name -and ($printers -contains $resolved.name))
  $hints = @($printers | Where-Object {
      ($_ -match 'brother|ql|epson|label|t[eé]rmic') -or ($_ -eq $resolved.name) -or ($script:PrinterNameEnv -and $_ -eq $script:PrinterNameEnv)
    })
  $mode = 'none'
  if ($resolved.name) { $mode = 'windows' }
  $online = @{ online = $null; reason = 'no listada' }
  if ($namedOk) { $online = Get-PrinterOnline -Printer $resolved.name }
  return @{
    printers            = @($printers)
    qlHints             = @($hints)
    resolved            = $resolved
    namedOk             = $namedOk
    reachable           = $namedOk
    printerOnline       = $online.online
    printerOnlineReason = $online.reason
    mode                = $mode
  }
}

function Get-RememberedColorMode {
  # Ultimo modo que funciono (lo escribe print-label.ps1 en state.json).
  param([string]$Printer)
  if (-not $Printer) { return $null }
  try {
    if (-not (Test-Path -LiteralPath $script:StatePath)) { return $null }
    $obj = Get-Content -LiteralPath $script:StatePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($null -eq $obj -or $null -eq $obj.printers) { return $null }
    $p = $obj.printers.PSObject.Properties[$Printer]
    if ($p -and $p.Value -and $p.Value.colorMode) { return [string]$p.Value.colorMode }
  }
  catch { }
  return $null
}

function ConvertTo-ColorMode {
  param($Value)
  $v = ('' + $Value).Trim().ToLowerInvariant()
  if (-not $v) { return 'auto' }
  if ($v -in @('color', 'red', 'rojo', 'negro/rojo', 'black/red')) { return 'redblack' }
  if ($v -in @('monochrome', 'monocromo', 'bw')) { return 'mono' }
  if ($v -in @('auto', 'mono', 'redblack')) { return $v }
  return 'auto'
}

# ---------------------------------------------------------------------------
# HTTP: utilidades
# ---------------------------------------------------------------------------

function Add-CorsHeaders {
  param([System.Net.HttpListenerRequest]$Request, [System.Net.HttpListenerResponse]$Response)
  $origin = ''
  try { $origin = ('' + $Request.Headers['Origin']).Trim() } catch { $origin = '' }
  if (-not $origin) { $allow = '*' }
  elseif ($origin -match $script:AllowedOriginRe) { $allow = $origin }
  else { $allow = 'https://panel.experiencebt.com.mx' }
  $Response.Headers.Set('Access-Control-Allow-Origin', $allow)
  $Response.Headers.Set('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
  $Response.Headers.Set('Access-Control-Allow-Headers', 'content-type, authorization')
  # Chrome Private/Local Network Access: pagina https publica -> 127.0.0.1
  $Response.Headers.Set('Access-Control-Allow-Private-Network', 'true')
  $Response.Headers.Set('Access-Control-Max-Age', '600')
  $Response.Headers.Set('Vary', 'Origin')
}

function Send-Json {
  param($Context, [int]$Status, $Body)
  $res = $Context.Response
  try {
    Add-CorsHeaders -Request $Context.Request -Response $res
    $json = ConvertTo-Json -InputObject $Body -Compress -Depth 8
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.StatusCode = $Status
    $res.ContentType = 'application/json; charset=utf-8'
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
  }
  catch {
    Write-AgentLog "no se pudo responder ($Status): $($_.Exception.Message)" 'WARN'
  }
  finally {
    try { $res.Close() } catch { }
  }
}

function Send-Empty {
  param($Context, [int]$Status)
  $res = $Context.Response
  try {
    Add-CorsHeaders -Request $Context.Request -Response $res
    $res.StatusCode = $Status
  }
  catch { }
  finally {
    try { $res.Close() } catch { }
  }
}

function Send-Error {
  param($Context, [int]$Status, [string]$Message)
  Send-Json -Context $Context -Status $Status -Body ([ordered]@{ ok = $false; error = $Message })
}

function Read-RequestBody {
  param([System.Net.HttpListenerRequest]$Request)
  if (-not $Request.HasEntityBody) { return '' }
  $sr = New-Object IO.StreamReader($Request.InputStream, [Text.Encoding]::UTF8)
  try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
}

function Get-Prop {
  # Propiedad de un PSCustomObject (JSON) o $null si no existe.
  param($Object, [string]$Name)
  if ($null -eq $Object) { return $null }
  $p = $Object.PSObject.Properties[$Name]
  if ($null -eq $p) { return $null }
  return $p.Value
}

function Get-Text {
  param($Object, [string]$Name)
  $v = Get-Prop -Object $Object -Name $Name
  if ($null -eq $v) { return '' }
  return ('' + $v)
}

function Test-Auth {
  param([System.Net.HttpListenerRequest]$Request)
  if (-not $script:Token) { return $true }
  $h = ''
  try { $h = ('' + $Request.Headers['Authorization']).Trim() } catch { $h = '' }
  if ($h -ceq ('Bearer ' + $script:Token)) { return $true }
  if ($h -ceq $script:Token) { return $true }
  return $false
}

function ConvertTo-ArgvQuoted {
  # Cita un argumento segun las reglas de CommandLineToArgvW (lo que hace Node en spawn).
  param([string]$Value)
  if ($null -eq $Value -or $Value -eq '') { return '""' }
  if ($Value -notmatch '[\s"]') { return $Value }
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append('"')
  $backslashes = 0
  foreach ($ch in $Value.ToCharArray()) {
    if ($ch -eq '\') { $backslashes++; continue }
    if ($ch -eq '"') {
      [void]$sb.Append('\', ($backslashes * 2 + 1))
      [void]$sb.Append('"')
      $backslashes = 0
      continue
    }
    if ($backslashes -gt 0) { [void]$sb.Append('\', $backslashes); $backslashes = 0 }
    [void]$sb.Append($ch)
  }
  if ($backslashes -gt 0) { [void]$sb.Append('\', ($backslashes * 2)) }
  [void]$sb.Append('"')
  return $sb.ToString()
}

# ---------------------------------------------------------------------------
# Impresion: cola de trabajos (uno a la vez) sobre print-label.ps1
# ---------------------------------------------------------------------------

$script:PrintQueue = New-Object System.Collections.Generic.Queue[object]
$script:ActiveJob = $null

function Start-PrintJob {
  param([hashtable]$Item)
  $spec = $Item.Spec
  $pngPath = ''
  if ($spec.pngBase64) {
    $clean = [regex]::Replace($spec.pngBase64, '\s', '')
    $bytes = [Convert]::FromBase64String($clean)
    $pngPath = Join-Path ([IO.Path]::GetTempPath()) ('ql-label-' + [Guid]::NewGuid().ToString('N').Substring(0, 16) + '.png')
    [IO.File]::WriteAllBytes($pngPath, $bytes)
  }

  $argv = New-Object System.Collections.Generic.List[string]
  foreach ($a in @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', $script:PrintScript,
      '-PrinterName', $spec.printerName, '-JobName', $script:JobName, '-Title', $spec.title)) { $argv.Add($a) }
  if ($spec.body) { $argv.Add('-Body'); $argv.Add($spec.body) }
  if ($spec.footer) { $argv.Add('-Footer'); $argv.Add($spec.footer) }
  $argv.Add('-WidthHmm'); $argv.Add([string][int][Math]::Round($spec.widthMm * 100))
  $argv.Add('-HeightHmm'); $argv.Add([string][int][Math]::Round($spec.heightMm * 100))
  if ($spec.mediaName) { $argv.Add('-MediaName'); $argv.Add($spec.mediaName) }
  if ($pngPath) { $argv.Add('-PngPath'); $argv.Add($pngPath) }
  $argv.Add('-ColorMode'); $argv.Add($spec.colorMode)
  $argv.Add('-RequireMediaMatch')

  $quoted = @($argv | ForEach-Object { ConvertTo-ArgvQuoted $_ })

  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $script:PowerShellExe
  $psi.Arguments = ($quoted -join ' ')
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.StandardOutputEncoding = [Console]::OutputEncoding
  $psi.StandardErrorEncoding = [Console]::OutputEncoding
  $psi.WorkingDirectory = $script:Root

  Write-AgentLog ("print job={0} printer={1} media={2} png={3} color={4}" -f $script:JobName, $spec.printerName, $spec.mediaName, [bool]$pngPath, $spec.colorMode)

  $proc = [System.Diagnostics.Process]::Start($psi)
  $script:ActiveJob = @{
    Context = $Item.Context
    Spec    = $spec
    Process = $proc
    Stdout  = $proc.StandardOutput.ReadToEndAsync()
    Stderr  = $proc.StandardError.ReadToEndAsync()
    PngPath = $pngPath
    Started = Get-Date
  }
}

function ConvertFrom-StdErr {
  # Deja legible el Write-Error de print-label.ps1 (quita ruta del script y lineas "+ CategoryInfo").
  param([string]$Text)
  $lines = @(($Text -split '\r?\n') | ForEach-Object { $_.TrimEnd() } | Where-Object { $_.Trim() -ne '' -and $_.Trim() -notmatch '^\+ ' })
  $joined = ($lines -join ' ').Trim()
  $joined = [regex]::Replace($joined, '^[^:]*print-label\.ps1\s*:\s*', '')
  return $joined
}

function Complete-PrintJob {
  param([hashtable]$Job, [bool]$TimedOut)
  $proc = $Job.Process
  $code = -1
  $out = ''
  $err = ''
  try {
    if ($TimedOut) {
      try { $proc.Kill() } catch { }
    }
    $proc.WaitForExit()
    $code = $proc.ExitCode
    try { $out = ('' + $Job.Stdout.Result).Trim() } catch { $out = '' }
    try { $err = ('' + $Job.Stderr.Result).Trim() } catch { $err = '' }
  }
  finally {
    try { $proc.Dispose() } catch { }
    if ($Job.PngPath) { Remove-Item -LiteralPath $Job.PngPath -Force -ErrorAction SilentlyContinue }
  }

  $parsed = $null
  $lines = @(($out -split '\r?\n') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
  for ($i = $lines.Count - 1; $i -ge 0; $i--) {
    if ($lines[$i].StartsWith('{')) {
      try { $parsed = $lines[$i] | ConvertFrom-Json -ErrorAction Stop } catch { $parsed = $null }
      break
    }
  }

  $spec = $Job.Spec
  $ctx = $Job.Context

  if ($TimedOut) {
    $msg = "print-label.ps1 no termino en $($script:PrintTimeoutSec) s; se cancelo. Revisa la cola de impresion de Windows."
    Write-AgentLog "FAIL job=$($script:JobName): $msg" 'ERROR'
    Send-Error -Context $ctx -Status 500 -Message $msg
    return
  }

  if ($code -eq 0) {
    $paper = Get-Prop $parsed 'paper'
    Write-AgentLog ("OK job={0} paper={1} how={2} color={3} watched={4}" -f $script:JobName, $paper, (Get-Prop $parsed 'matchHow'), (Get-Prop $parsed 'colorMode'), (Get-Prop $parsed 'watched'))
    $mode = Get-Prop $parsed 'mode'
    if (-not $mode) { if ($Job.PngPath) { $mode = 'png' } else { $mode = 'text' } }
    $attempts = Get-Prop $parsed 'attempts'
    if ($null -eq $attempts) { $attempts = @() }
    $body = [ordered]@{
      ok              = $true
      via             = 'windows'
      printer         = $spec.printerName
      documentName    = $script:JobName
      paper           = $paper
      paperWidthHi    = Get-Prop $parsed 'paperWidthHi'
      paperHeightHi   = Get-Prop $parsed 'paperHeightHi'
      matchHow        = Get-Prop $parsed 'matchHow'
      mode            = $mode
      colorMode       = Get-Prop $parsed 'colorMode'
      colorModeSource = Get-Prop $parsed 'colorModeSource'
      watched         = Get-Prop $parsed 'watched'
      jobStatus       = Get-Prop $parsed 'jobStatus'
      jobId           = Get-Prop $parsed 'jobId'
      attempts        = @($attempts)
      windowsSynced   = [bool](Get-Prop $parsed 'windowsSynced')
      stdout          = $out
      printerSource   = $spec.printerSource
      jobName         = $script:JobName
      mediaName       = $spec.mediaName
      widthMm         = $spec.widthMm
      heightMm        = $spec.heightMm
    }
    Send-Json -Context $ctx -Status 200 -Body $body
    return
  }

  $msg = ConvertFrom-StdErr $err
  if (-not $msg -and $parsed) { $msg = ('' + (Get-Prop $parsed 'error')) }
  if (-not $msg) { $msg = $out }
  if (-not $msg) { $msg = "PowerShell exit $code (impresion fallida; no se uso Chrome)" }
  Write-AgentLog "FAIL job=$($script:JobName): $msg" 'ERROR'
  $stdoutShort = $out
  if ($stdoutShort.Length -gt 4000) { $stdoutShort = $stdoutShort.Substring($stdoutShort.Length - 4000) }
  Send-Json -Context $ctx -Status 500 -Body ([ordered]@{ ok = $false; error = $msg; exitCode = $code; stdout = $stdoutShort })
}

function Update-PrintJobs {
  # Se llama en cada vuelta del bucle principal (cada ~100 ms).
  if ($null -ne $script:ActiveJob) {
    $job = $script:ActiveJob
    $exited = $false
    try { $exited = $job.Process.HasExited } catch { $exited = $true }
    if ($exited) {
      $script:ActiveJob = $null
      try { Complete-PrintJob -Job $job -TimedOut $false }
      catch {
        Write-AgentLog "error cerrando job: $($_.Exception.Message)" 'ERROR'
        Send-Error -Context $job.Context -Status 500 -Message $_.Exception.Message
      }
    }
    elseif (((Get-Date) - $job.Started).TotalSeconds -gt $script:PrintTimeoutSec) {
      $script:ActiveJob = $null
      try { Complete-PrintJob -Job $job -TimedOut $true }
      catch { Send-Error -Context $job.Context -Status 500 -Message $_.Exception.Message }
    }
  }
  while ($null -eq $script:ActiveJob -and $script:PrintQueue.Count -gt 0) {
    $item = $script:PrintQueue.Dequeue()
    try {
      Start-PrintJob -Item $item
    }
    catch {
      $ex = $_.Exception
      # PowerShell envuelve las excepciones .NET en MethodInvocationException: mirar tambien InnerException.
      $inner = $ex
      if ($ex.InnerException) { $inner = $ex.InnerException }
      $m = $inner.Message
      $status = 500
      if ($inner -is [FormatException]) { $status = 400; $m = "PNG base64 invalido: $m" }
      Write-AgentLog "no se pudo lanzar print-label.ps1: $m" 'ERROR'
      Send-Error -Context $item.Context -Status $status -Message $m
    }
  }
}

# ---------------------------------------------------------------------------
# Rutas
# ---------------------------------------------------------------------------

function Invoke-HealthRoute {
  param($Context)
  $override = ('' + $Context.Request.QueryString['printer']).Trim()
  $status = Get-PrinterStatus -Override $override
  $name = $status.resolved.name
  $printerEnv = $null
  if ($script:PrinterNameEnv) { $printerEnv = $script:PrinterNameEnv }
  $body = [ordered]@{
    ok            = $true
    reachable     = $status.reachable
    mode          = $status.mode
    printerName   = $name
    printerSource = $status.resolved.source
    printerEnv    = $printerEnv
    printerHost   = $null
    printerListed = $status.namedOk
    printerOnline = $status.printerOnline
    printerOnlineReason = $status.printerOnlineReason
    authRequired  = [bool]$script:Token
    jobName       = $script:JobName
    colorMode     = Get-RememberedColorMode -Printer $name
    agent         = 'powershell'
    version       = $script:Version
    installed     = $script:Installed
    pid           = $PID
    port          = $Port
    bind          = $Bind
    uptimeSec     = [int]((Get-Date) - $script:StartedAt).TotalSeconds
    scriptRoot    = $script:Root
    queue         = $script:PrintQueue.Count + $(if ($null -ne $script:ActiveJob) { 1 } else { 0 })
    label         = [ordered]@{
      widthMm   = $script:LabelWidthMm
      heightMm  = $script:LabelHeightMm
      mediaName = $(if ($script:LabelMediaName) { $script:LabelMediaName } else { $null })
    }
    printers      = @($status.qlHints)
    printersAll   = @($status.printers)
  }
  Send-Json -Context $Context -Status 200 -Body $body
}

function Invoke-PrintersRoute {
  param($Context)
  $override = ('' + $Context.Request.QueryString['printer']).Trim()
  $status = Get-PrinterStatus -Override $override
  $printerEnv = $null
  if ($script:PrinterNameEnv) { $printerEnv = $script:PrinterNameEnv }
  Send-Json -Context $Context -Status 200 -Body ([ordered]@{
      ok         = $true
      printers   = @($status.printers)
      preferred  = @($status.qlHints)
      selected   = $status.resolved.name
      source     = $status.resolved.source
      printerEnv = $printerEnv
    })
}

function Invoke-PrintLabelRoute {
  param($Context, [bool]$IsTest)
  $raw = Read-RequestBody -Request $Context.Request
  $payload = $null
  if ($raw.Trim() -ne '') {
    try { $payload = $raw | ConvertFrom-Json -ErrorAction Stop }
    catch {
      Send-Error -Context $Context -Status 400 -Message 'JSON inválido'
      return
    }
    if ($null -ne $payload -and -not ($payload -is [System.Management.Automation.PSCustomObject])) {
      Send-Error -Context $Context -Status 400 -Message 'JSON inválido (se esperaba un objeto)'
      return
    }
  }

  $override = (Get-Text $payload 'printerName').Trim()
  if (-not $override) { $override = (Get-Text $payload 'printer').Trim() }
  $status = Get-PrinterStatus -Override $override
  $printerName = $status.resolved.name
  if (-not $printerName) {
    Send-Error -Context $Context -Status 500 -Message 'No hay impresora QL-800. Instala el driver Brother, conecta USB y reinicia el agente (o elige una en la UI).'
    return
  }

  $culture = [Globalization.CultureInfo]::GetCultureInfo('es-MX')
  $now = (Get-Date).ToString('G', $culture)

  $title = Get-Text $payload 'title'
  if (-not $title) { if ($IsTest) { $title = 'EXPERIENCEBT · PRUEBA' } else { $title = 'EXPERIENCEBT' } }
  $bodyText = Get-Text $payload 'body'
  if (-not $bodyText -and $IsTest) { $bodyText = "Etiqueta de prueba`n$now`nImpresora: $printerName" }
  $footer = Get-Text $payload 'footer'
  if (-not $footer) { $footer = 'QL local · no prod Hetzner' }

  $png = Get-Text $payload 'pngBase64'
  if (-not $png) { $png = Get-Text $payload 'imageBase64' }
  if (-not $png) { $png = Get-Text $payload 'png' }
  $png = [regex]::Replace($png, '^data:image/[^;]+;base64,', '').Trim()

  $mediaName = (Get-Text $payload 'mediaName').Trim()
  if (-not $mediaName) { $mediaName = $script:LabelMediaName }

  $spec = @{
    printerName   = $printerName
    printerSource = $status.resolved.source
    title         = $title
    body          = $bodyText
    footer        = $footer
    widthMm       = ConvertTo-Number (Get-Prop $payload 'widthMm') $script:LabelWidthMm
    heightMm      = ConvertTo-Number (Get-Prop $payload 'heightMm') $script:LabelHeightMm
    mediaName     = $mediaName
    pngBase64     = $png
    colorMode     = ConvertTo-ColorMode (Get-Prop $payload 'colorMode')
  }
  $script:PrintQueue.Enqueue(@{ Context = $Context; Spec = $spec })
  if ($null -ne $script:ActiveJob) {
    Write-AgentLog "impresion encolada (en cola: $($script:PrintQueue.Count))"
  }
}

function Invoke-Request {
  param($Context)
  $req = $Context.Request
  $method = ('' + $req.HttpMethod).ToUpperInvariant()
  $path = $req.Url.AbsolutePath

  if ($method -eq 'OPTIONS') { Send-Empty -Context $Context -Status 204; return }

  if (-not (Test-Auth -Request $req)) {
    Send-Error -Context $Context -Status 401 -Message 'Token inválido (PRINT_BRIDGE_TOKEN)'
    return
  }

  if ($method -eq 'GET' -and $path -eq '/health') { Invoke-HealthRoute -Context $Context; return }
  if ($method -eq 'GET' -and $path -eq '/printers') { Invoke-PrintersRoute -Context $Context; return }
  if ($method -eq 'POST' -and $path -eq '/print') {
    Send-Error -Context $Context -Status 400 -Message 'POST /print es ESC/POS crudo (Ethernet 9100) y este agente PowerShell no lo soporta. Para Brother QL-800 usa POST /test o /print-label.'
    return
  }
  if ($method -eq 'POST' -and ($path -eq '/print-label' -or $path -eq '/test')) {
    Invoke-PrintLabelRoute -Context $Context -IsTest ($path -eq '/test')
    return
  }
  Send-Error -Context $Context -Status 404 -Message 'Not found'
}

# ---------------------------------------------------------------------------
# Arranque
# ---------------------------------------------------------------------------

if (-not (Test-Path -LiteralPath $script:PrintScript)) {
  Write-AgentLog "falta print-label.ps1 junto a agent.ps1 ($($script:Root))" 'ERROR'
  exit 1
}

# Guardia de instancia unica: si alguien ya escucha en el puerto, salir en silencio (codigo 0).
try {
  $busy = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop)
}
catch { $busy = @() }
if ($busy.Count -gt 0) {
  $owner = ''
  $ownerPid = [int]$busy[0].OwningProcess
  if ($ownerPid -le 4) {
    # http.sys (PID 4 = System) responde por otro HttpListener: casi seguro otro agent.ps1.
    $owner = 'http.sys (otro agente PowerShell ya activo)'
    try {
      $prev = (Get-Content -LiteralPath $script:PidPath -ErrorAction Stop | Select-Object -First 1).Trim()
      if ($prev) { $owner += " PID $prev" }
    }
    catch { }
  }
  else {
    try {
      $p = Get-Process -Id $ownerPid -ErrorAction Stop
      $owner = "$($p.ProcessName) (PID $($p.Id))"
    }
    catch { $owner = "PID $ownerPid" }
  }
  Write-AgentLog "puerto $Port ya en uso por $owner; esta instancia (PID $PID) no arranca" 'WARN'
  exit 0
}

$prefixes = @()
if ($Bind -in @('127.0.0.1', 'localhost')) {
  $prefixes = @("http://127.0.0.1:$Port/", "http://localhost:$Port/")
}
else {
  $prefixes = @("http://$Bind`:$Port/")
}

$listener = New-Object System.Net.HttpListener
foreach ($prefix in $prefixes) { $listener.Prefixes.Add($prefix) }
try {
  $listener.Start()
}
catch {
  Write-AgentLog "no se pudo escuchar en $($prefixes -join ', '): $($_.Exception.Message). Puerto ocupado; esta instancia (PID $PID) no arranca" 'WARN'
  exit 0
}

try { Set-Content -LiteralPath $script:PidPath -Value $PID -Encoding ASCII -ErrorAction SilentlyContinue } catch { }

Write-AgentLog "agente PowerShell v$($script:Version) PID $PID escuchando en $($prefixes -join ' y ')"
Write-AgentLog "script=$($script:Root) instalado=$($script:Installed)"
Write-AgentLog ("PRINTER_NAME env={0}" -f $(if ($script:PrinterNameEnv) { $script:PrinterNameEnv } else { '(vacio -> auto-detect)' }))
Write-AgentLog ("label {0}x{1} mm media={2}" -f $script:LabelWidthMm, $script:LabelHeightMm, $(if ($script:LabelMediaName) { $script:LabelMediaName } else { '(auto)' }))
if ($script:Token) { Write-AgentLog 'PRINT_BRIDGE_TOKEN activo (Authorization requerido)' }
try {
  $st = Get-PrinterStatus -Override ''
  Write-AgentLog ("resuelto={0} fuente={1} instaladas={2}" -f $(if ($st.resolved.name) { $st.resolved.name } else { '(ninguna)' }), $st.resolved.source, $st.printers.Count)
}
catch {
  Write-AgentLog "no se pudo listar impresoras: $($_.Exception.Message)" 'WARN'
}
Write-AgentLog 'Ctrl+C para detener. En Accesos: Imprimir en QL (agente local).'

if ($OpenBrowser) {
  try { Start-Process "http://127.0.0.1:$Port/health" } catch { }
}

$ctxTask = $listener.GetContextAsync()
try {
  while ($listener.IsListening) {
    $got = $false
    try {
      $got = $ctxTask.Wait(100)
    }
    catch {
      if (-not $listener.IsListening) { break }
      Write-AgentLog "listener: $($_.Exception.Message)" 'WARN'
      $ctxTask = $listener.GetContextAsync()
      continue
    }
    if ($got) {
      $ctx = $ctxTask.Result
      $ctxTask = $listener.GetContextAsync()
      try {
        Invoke-Request -Context $ctx
      }
      catch {
        Write-AgentLog "error atendiendo $($ctx.Request.HttpMethod) $($ctx.Request.Url.AbsolutePath): $($_.Exception.Message)" 'ERROR'
        Send-Error -Context $ctx -Status 500 -Message $_.Exception.Message
      }
    }
    Update-PrintJobs
  }
}
finally {
  try { $listener.Stop() } catch { }
  try { $listener.Close() } catch { }
  if ($null -ne $script:ActiveJob) {
    try { $script:ActiveJob.Process.Kill() } catch { }
    if ($script:ActiveJob.PngPath) { Remove-Item -LiteralPath $script:ActiveJob.PngPath -Force -ErrorAction SilentlyContinue }
  }
  try {
    if ((Test-Path -LiteralPath $script:PidPath) -and ((Get-Content -LiteralPath $script:PidPath -ErrorAction SilentlyContinue) -eq "$PID")) {
      Remove-Item -LiteralPath $script:PidPath -Force -ErrorAction SilentlyContinue
    }
  }
  catch { }
  Write-AgentLog "agente detenido (PID $PID)"
}
