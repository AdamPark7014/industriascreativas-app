# ExperienceBT Print Bridge — Brother QL-800

Agente **local** para imprimir gafetes desde Accesos (`panel.experiencebt.com.mx`)
en **esta** PC. El servidor en la nube **no** puede hablar con una impresora USB.

```
Browser (Accesos) → http://127.0.0.1:9631 → Spooler Windows → Brother QL-800 USB
```

## 3 pasos (cualquier PC de recepción)

1. Conecta la **Brother QL-800** por USB e instala el driver Brother (aparece en Impresoras).
2. Descomprime este ZIP y haz doble clic en **`start.cmd`**.
3. En Accesos → Buscar → Ver e imprimir → **Imprimir en QL (agente local)**.

Requisito: **Node.js 20+** en PATH ([nodejs.org](https://nodejs.org)). Si no hay Node, instálalo y vuelve a abrir `start.cmd`.

## Qué hace `start.cmd`

- Crea `.env` desde `.env.example` si falta (PRINTER_NAME vacío = auto-detect QL-800).
- Arranca el agente en `http://127.0.0.1:9631`.
- Abre `/health` en el navegador.

## Media por defecto

| Parámetro | Valor |
|-----------|--------|
| Ancho | 62 mm |
| Corte | ~100 mm |
| Nombre Windows (ES) | `62mm Cinta continua` |
| Job name en cola | `ExperienceBT-QL-62x100` |

**No** uses die-cut 29×90 ni 62×29 si el rollo es cinta continua 62 mm.

## Una vez por PC (recomendado)

Tras instalar el driver:

```powershell
pwsh -File .\set-ql-media.ps1
```

Fija el papel por defecto del spooler a **62mm Cinta continua** (evita que Chrome
remapee a 29×90 si alguien usa el diálogo de impresión del navegador).

## Probar sin Accesos

```powershell
Invoke-RestMethod http://127.0.0.1:9631/health
Invoke-RestMethod -Method POST http://127.0.0.1:9631/test -ContentType 'application/json' -Body '{}'
```

## CORS

Orígenes permitidos: `https://panel.experiencebt.com.mx`,
`https://demo.experiencebt.com.mx`, `http://localhost:*`, `http://127.0.0.1:*`.

## Archivos

| Archivo | Rol |
|---------|-----|
| `start.cmd` / `start.ps1` | Arranque one-click |
| `server.mjs` | HTTP local :9631 |
| `print-label.ps1` | GDI → spooler (fuerza media 62 mm) |
| `set-ql-media.ps1` | Preferencia Windows 62 mm continua |
| `.env.example` | Defaults (copiar a `.env`) |
