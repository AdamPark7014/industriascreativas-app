# ExperienceBT Print Bridge — Brother QL-800

Agente **local** para imprimir gafetes desde Accesos (`panel.experiencebt.com.mx`)
en **esta** PC. El servidor en la nube **no** puede hablar con una impresora USB.

```
Browser (Accesos) → http://127.0.0.1:9631 → agent.ps1 → print-label.ps1 → Spooler Windows → Brother QL-800 USB
```

Solo necesita **Windows PowerShell 5.1** (viene con Windows 10/11). **Sin Node, sin admin.**

## Instalar en 3 pasos (cualquier PC de recepción)

1. Instala el **driver Brother QL-800** y conecta la impresora por USB (debe aparecer en
   Configuración → Impresoras). Driver oficial:
   <https://support.brother.com/g/b/downloadtop.aspx?c=us&lang=en&prod=lpql800eus>
2. Descarga `print-bridge-windows.zip`, clic derecho → **Extraer todo**.
3. En la carpeta extraída, doble clic en **`Instalar-Impresora-QL.cmd`**.

Al terminar verás **«Listo. En Accesos usa Imprimir en QL.»**, se abre `/health` en el
navegador y sale una etiqueta de prueba. Desde entonces el agente arranca solo con Windows,
sin ventana. En Accesos → Buscar → Ver e imprimir → **Imprimir en QL (agente local)**.

Si Windows muestra «Windows protegió su PC» (SmartScreen) al abrir el `.cmd`: **Más
información → Ejecutar de todas formas**. El instalador quita la marca de Internet de los
archivos por ti.

## Qué hace `Instalar-Impresora-QL.cmd`

1. Desbloquea los archivos descargados (Mark-of-the-Web).
2. Copia todo a `%LOCALAPPDATA%\ExperienceBT\print-bridge\app\`.
3. Crea el acceso directo **ExperienceBT Impresora QL** en Inicio (`shell:startup`), que
   lanza `wscript.exe run-hidden.vbs` → `agent.ps1` oculto.
4. Comprueba que exista una impresora `QL-800`; si no, abre la página del driver y termina
   (vuelve a ejecutar el instalador cuando el driver esté).
5. Fija el papel por defecto de la QL-800 a **62 mm cinta continua** editando solo
   `PageMediaSize` del PrintTicket (no toca el tipo de rollo).
6. Detiene cualquier agente previo en el puerto (Node o PowerShell).
7. Arranca el agente oculto, espera `/health` (15 s), abre `/health` y lanza `POST /test`.

Opciones: `install.ps1 -NoTest -NoBrowser -Port 9631`.

## Auto-detección de rollo (mono / negro-rojo)

La Brother exige que el «Tipo de papel» del driver coincida con el rollo físico: **DK-2251
negro/rojo** → `psk:Color`; **monocromo** (DK-22205, etc.) → `psk:Monochrome`. Si no
coincide, la impresora pausa el trabajo con error y no sale nada.

`print-label.ps1` lo resuelve solo en cada impresión: usa el último modo que funcionó
(`state.json`) → el default de Windows → el otro; vigila la cola y, si la Brother pausa el
job con error, lo cancela y reintenta con el otro modo. El modo que funcionó se guarda en
`%LOCALAPPDATA%\ExperienceBT\print-bridge\state.json` y se replica al default de Windows
(así Chrome y P-touch también coinciden). Puedes forzarlo con `colorMode: "mono" | "redblack"`
en el POST.

## Qué hace el agente (`agent.ps1`)

- Escucha en `http://127.0.0.1:9631` (y `localhost`) con `System.Net.HttpListener`.
- CORS para `https://panel.experiencebt.com.mx`, `https://demo.experiencebt.com.mx`,
  `http://localhost:*`, `http://127.0.0.1:*`, con `Access-Control-Allow-Private-Network: true`
  (Chrome pide permiso de «red local» la primera vez: **Permitir**).
- Por cada impresión lanza `powershell.exe -File print-label.ps1` (PNG a archivo temporal,
  que borra después); las impresiones van de una en una y `/health` sigue respondiendo mientras.
- Log en `%LOCALAPPDATA%\ExperienceBT\print-bridge\agent.log` (rota a `.1` al pasar de 1 MB).
- Instancia única: si el puerto ya está ocupado, lo anota en el log y sale con código 0.

## Verificar

```powershell
Invoke-RestMethod http://127.0.0.1:9631/health
```

Debe responder `ok: true`, `agent: "powershell"`, `installed: true`, `printerName` con la
QL-800, `colorMode` con el rollo detectado (`mono` / `redblack`, o `null` hasta la primera
impresión) y `printersAll` con las impresoras de Windows.

```powershell
Invoke-RestMethod -Method POST http://127.0.0.1:9631/test -ContentType 'application/json' -Body '{}'
```

Para ver el agente en una ventana (depuración): doble clic en `start.cmd`.

## Problemas típicos

| Síntoma | Qué hacer |
|---------|-----------|
| Chrome pregunta si permite acceder a la **red local** / dispositivos locales | **Permitir**. Si lo negaste: candado de la barra de direcciones → Permisos del sitio → Red local → Permitir, y recarga. |
| La Brother parpadea y en el estado dice «cambie el tipo de papel» / «el rollo no coincide» | El agente reintenta solo con el otro modo. Si sigue: comprueba que el rollo sea **62 mm cinta continua** (no 29×90 ni 62×29 troquelado). |
| «Tapa abierta» / luz roja | Cierra la tapa hasta que haga clic, comprueba que el rollo esté bien asentado y reintenta. |
| Cola atascada (trabajos en Error / Pausado) | Configuración → Impresoras → Brother QL-800 → Abrir cola → cancelar todos; apaga y enciende la impresora; reintenta. |
| Accesos dice «Puente inaccesible» | `Invoke-RestMethod http://127.0.0.1:9631/health`. Si no responde: `start.cmd` para verlo con ventana, o vuelve a ejecutar `Instalar-Impresora-QL.cmd`. Mira `agent.log`. |
| No aparece ninguna `QL-800` en `printersAll` | Driver Brother no instalado o USB desconectado. Instala el driver y reinicia el agente (o el instalador). |
| El agente no arranca al iniciar sesión | Comprueba que exista `ExperienceBT Impresora QL.lnk` en `shell:startup`; si no, repite el instalador. |

## Desinstalar

Doble clic en **`Desinstalar-Impresora-QL.cmd`** (o `uninstall.ps1`): para el agente, quita el
acceso directo de Inicio y borra `%LOCALAPPDATA%\ExperienceBT\print-bridge\app`. Conserva
`state.json` (rollo detectado) y `agent.log`. No toca el driver Brother.

## Media por defecto

| Parámetro | Valor |
|-----------|--------|
| Ancho | 62 mm |
| Corte | ~100 mm |
| Nombre Windows (ES) | `62mm Cinta continua` (GDI: `62mm`) |
| Job name en cola | `ExperienceBT-QL-62x100` |

**No** uses die-cut 29×90 ni 62×29 si el rollo es cinta continua 62 mm.

## API

| Método | Ruta | Uso |
|--------|------|-----|
| `OPTIONS` | `*` | Preflight CORS (204) |
| `GET` | `/health` | Estado, impresora resuelta, `colorMode`, `agent`, `version`, `installed` |
| `GET` | `/printers` | Impresoras Windows + `selected` |
| `POST` | `/test` | Etiqueta de prueba |
| `POST` | `/print-label` | Etiqueta: `title`, `body`, `footer`, `pngBase64` (o `imageBase64` / `png`, con o sin `data:`), `widthMm`, `heightMm`, `mediaName`, `printerName`, `colorMode` (`auto` / `mono` / `redblack`) |
| `POST` | `/print` | ESC/POS crudo: solo en `server.mjs` (Node) con `PRINTER_HOST` |

Respuesta de impresión: `ok`, `via`, `printer`, `printerSource`, `documentName`, `paper`,
`matchHow`, `mode` (`text` / `png`), `colorMode`, `colorModeSource`, `watched`, `jobStatus`,
`jobId`, `attempts`, `windowsSynced`, `jobName`, `mediaName`, `widthMm`, `heightMm`.
Error → `{ "ok": false, "error": "..." }` con 4xx/5xx.

Resolución de impresora: `printerName` del body (o `?printer=`) si está instalada →
`PRINTER_NAME` de `.env` si está instalada → primera `Brother QL-800` → primera `QL-800`.

## Variables (`.env`, opcional)

`.env` junto a `agent.ps1` (instalado: `%LOCALAPPDATA%\ExperienceBT\print-bridge\app\.env`).
Sin `.env` se usan los defaults. Tras cambiarlo, reinicia el agente (instalador o `start.cmd`).

| Variable | Default | Notas |
|----------|---------|--------|
| `PORT` / `BIND` | `9631` / `127.0.0.1` | Solo localhost |
| `PRINTER_NAME` | vacío | Vacío = auto-detect QL-800 |
| `LABEL_WIDTH_MM` / `LABEL_HEIGHT_MM` | `62` / `100` | Cinta continua 62 mm, corte ~100 mm |
| `LABEL_MEDIA_NAME` | `62mm Cinta continua` | Nombre del papel en el driver (EN: `62mm Continuous`) |
| `PRINT_BRIDGE_TOKEN` | vacío | Si se define, exige `Authorization: Bearer <token>` |

## Archivos

| Archivo | Rol |
|---------|-----|
| `Instalar-Impresora-QL.cmd` / `install.ps1` | Instalación por usuario (sin admin) |
| `Desinstalar-Impresora-QL.cmd` / `uninstall.ps1` | Desinstalación |
| `agent.ps1` | Agente HTTP local (PowerShell 5.1) |
| `run-hidden.vbs` | Arranca `agent.ps1` sin ventana (lo usa Inicio) |
| `print-label.ps1` | GDI → spooler; fuerza 62 mm y detecta el rollo |
| `start.cmd` | Agente visible (depuración) |
| `set-ql-media.ps1` | Manual: papel default 62 mm (el instalador ya lo hace) |
| `start-node.cmd` / `start.ps1` / `server.mjs` | Alternativa con Node 20+ (mismo contrato) |
| `pack.ps1` | Genera `dist/print-bridge-windows.zip` (`-CopyTo` para copiarlo) |
| `.env.example` | Variables opcionales |

Alternativa con Node (si alguien la prefiere): `start-node.cmd` arranca `server.mjs` con el
mismo contrato HTTP. No la necesitas para el uso normal.
