' ExperienceBT - arranca el agente de impresion QL-800 (agent.ps1) sin ventana.
' Lo usa el acceso directo de la carpeta Inicio del usuario. Argumentos extra
' (p. ej. -Port 9641) se pasan tal cual a agent.ps1.
Option Explicit

Dim fso, sh, dir, ps, cmd, i
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

dir = fso.GetParentFolderName(WScript.ScriptFullName)
ps = sh.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"

cmd = """" & ps & """ -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\agent.ps1"""
For i = 0 To WScript.Arguments.Count - 1
  cmd = cmd & " " & WScript.Arguments(i)
Next

sh.CurrentDirectory = dir
' 0 = ventana oculta; False = no esperar (wscript termina y powershell sigue solo).
sh.Run cmd, 0, False
