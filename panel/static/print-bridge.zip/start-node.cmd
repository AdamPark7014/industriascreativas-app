@echo off
REM Arranque ALTERNATIVO con Node (server.mjs). Requiere Node 20+ en PATH.
REM Uso normal sin Node: Instalar-Impresora-QL.cmd (agente PowerShell) o start.cmd (visible).
cd /d "%~dp0"
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" -OpenBrowser
if errorlevel 1 (
  echo.
  echo Si pwsh no existe, prueba: powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" -OpenBrowser
  pause
)
