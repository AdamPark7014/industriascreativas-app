@echo off
REM ExperienceBT - Instalar el agente de impresion Brother QL-800 (doble clic).
REM Solo necesita Windows PowerShell 5.1 (viene con Windows). Sin Node, sin admin.
setlocal
title ExperienceBT - Instalar impresora QL
cd /d "%~dp0" 2>nul
if not exist "%~dp0install.ps1" (
  echo.
  echo No encuentro install.ps1 junto a este archivo.
  echo Si abriste el ZIP sin descomprimir: clic derecho en el ZIP, "Extraer todo",
  echo y vuelve a hacer doble clic en Instalar-Impresora-QL.cmd dentro de la carpeta extraida.
  echo.
  pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
set RC=%ERRORLEVEL%
echo.
if not "%RC%"=="0" echo La instalacion termino con codigo %RC%. Lee los mensajes de arriba.
pause
exit /b %RC%
