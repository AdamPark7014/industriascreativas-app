#Requires -Version 5.1
<#
.SYNOPSIS
  One-time: set Brother QL-800 Windows default media to 62mm continuous tape.
.DESCRIPTION
  Get-PrintConfiguration PaperSize enum cannot express Brother custom sizes.
  This writes a PrintTicket with CustomMediaSize259 (DisplayName "62mm",
  ContinuousLengthTape) — what the Brother UI shows as "62mm Cinta continua".

  Exact command used (also runnable inline):
    Set-PrintConfiguration -PrinterName 'Brother QL-800' -PrintTicketXml $ticketXml
#>
param(
  [string]$PrinterName = 'Brother QL-800'
)

$ErrorActionPreference = 'Stop'

$before = Get-PrintConfiguration -PrinterName $PrinterName
Write-Host "BEFORE PrintTicket media:"
[regex]::Matches($before.PrintTicketXML, 'CustomMediaSize\d+|PaperType.{0,90}') |
  ForEach-Object { Write-Host ("  " + $_.Value) }

$ticket = @'
<?xml version="1.0"?>
<psf:PrintTicket xmlns:psf="http://schemas.microsoft.com/windows/2003/08/printing/printschemaframework" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1" xmlns:psk="http://schemas.microsoft.com/windows/2003/08/printing/printschemakeywords" xmlns:ns0001="http://schemas.brother.info/mfc/printing/2006/11/printschemakeywords">
  <psf:Feature name="psk:PageMediaSize">
    <psf:Option name="ns0001:CustomMediaSize259">
      <psf:ScoredProperty name="psk:MediaSizeWidth"><psf:Value xsi:type="xsd:integer">62000</psf:Value></psf:ScoredProperty>
      <psf:ScoredProperty name="psk:MediaSizeHeight"><psf:Value xsi:type="xsd:integer">100000</psf:Value></psf:ScoredProperty>
      <psf:ScoredProperty name="ns0001:MediaSizeHeightOffset"><psf:Value xsi:type="xsd:integer">3000</psf:Value></psf:ScoredProperty>
    </psf:Option>
  </psf:Feature>
  <psf:Feature name="psk:PageOrientation"><psf:Option name="psk:Portrait"/></psf:Feature>
  <psf:Feature name="ns0001:JobUnit"><psf:Option name="ns0001:mm"/></psf:Feature>
  <psf:Property name="ns0001:PageMediaSizeData">
    <psf:Property name="ns0001:PaperType"><psf:Value xsi:type="xsd:string">ContinuousLengthTape</psf:Value></psf:Property>
  </psf:Property>
  <psf:Feature name="psk:DocumentCollate"><psf:Option name="psk:Uncollated"/></psf:Feature>
  <psf:Feature name="psk:JobPageOrder"><psf:Option name="psk:Standard"/></psf:Feature>
  <psf:ParameterInit name="psk:JobCopiesAllDocuments"><psf:Value xsi:type="xsd:integer">1</psf:Value></psf:ParameterInit>
  <psf:Feature name="psk:PageMediaType"><psf:Option name="psk:Label"/></psf:Feature>
  <psf:Feature name="psk:PageResolution">
    <psf:Option>
      <psf:ScoredProperty name="psk:ResolutionX"><psf:Value xsi:type="xsd:integer">300</psf:Value></psf:ScoredProperty>
      <psf:ScoredProperty name="psk:ResolutionY"><psf:Value xsi:type="xsd:integer">300</psf:Value></psf:ScoredProperty>
    </psf:Option>
  </psf:Feature>
  <psf:Feature name="psk:PageOutputQuality"><psf:Option name="psk:Draft"/></psf:Feature>
  <psf:Feature name="psk:JobRollCutAtEndOfJob"><psf:Option name="psk:CutSheetAtStandardMediaSize"/></psf:Feature>
  <psf:Feature name="ns0001:JobRollCutSheet">
    <psf:Option name="ns0001:CutSheet">
      <psf:ScoredProperty name="ns0001:CutSheetCount"><psf:ParameterRef name="ns0001:JobCutSheetCount"/></psf:ScoredProperty>
    </psf:Option>
  </psf:Feature>
  <psf:ParameterInit name="ns0001:JobCutSheetCount"><psf:Value xsi:type="xsd:integer">1</psf:Value></psf:ParameterInit>
  <psf:Feature name="psk:PageOutputColor">
    <psf:Option name="psk:Monochrome">
      <psf:ScoredProperty name="psk:DeviceBitsPerPixel"><psf:Value xsi:type="xsd:integer">1</psf:Value></psf:ScoredProperty>
      <psf:ScoredProperty name="psk:DriverBitsPerPixel"><psf:Value xsi:type="xsd:integer">24</psf:Value></psf:ScoredProperty>
    </psf:Option>
  </psf:Feature>
</psf:PrintTicket>
'@

Set-PrintConfiguration -PrinterName $PrinterName -PrintTicketXml $ticket

$after = Get-PrintConfiguration -PrinterName $PrinterName
Write-Host "AFTER PrintTicket media:"
[regex]::Matches($after.PrintTicketXML, 'CustomMediaSize\d+|PaperType.{0,90}|MediaSizeWidth.{0,70}') |
  ForEach-Object { Write-Host ("  " + $_.Value) }
Write-Host ""
Write-Host "PaperSize enum property (often empty for Brother custom): [$($after.PaperSize)]"
Write-Host "OK — default is CustomMediaSize259 (62mm continuous / ContinuousLengthTape)."
Write-Host "Verify in Brother status: physical roll should match; Chrome jobs no longer prefer 29x90."
