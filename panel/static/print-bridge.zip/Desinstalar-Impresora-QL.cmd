@echo off
REM ExperienceBT - Desinstalar el agente de impresion Brother QL-800 (doble clic).
REM Para el agente, quita el arranque con Windows y borra la carpeta app. No toca el driver.
setlocal
title ExperienceBT - Desinstalar impresora QL
cd /d "%~dp0" 2>nul
if not exist "%~dp0uninstall.ps1" (
  echo.
  echo No encuentro uninstall.ps1 junto a este archivo. Descomprime el ZIP completo primero.
  echo.
  pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %*
set RC=%ERRORLEVEL%
echo.
pause
exit /b %RC%
